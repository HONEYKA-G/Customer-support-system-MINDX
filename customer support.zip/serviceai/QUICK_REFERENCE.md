# 📋 QUICK REFERENCE CARD - Copy & Paste

## 🚀 Start Application (One Command)
```bash
cd c:\Users\madhu\Downloads\serviceai\serviceai && mvnw.cmd spring-boot:run
```

Wait 5-10 seconds until you see:
```
✅ Sample Data Initialized Successfully!
```

---

## 🌐 Open These URLs (Copy Into Browser)

| Purpose | URL |
|---------|-----|
| **Main App** | `http://localhost:8080` |
| **Admin Dashboard** | `http://localhost:8080/admin` |
| **Database Console** | `http://localhost:8080/h2-console` |
| **API Tickets** | `http://localhost:8080/api/tickets` |

---

## 📋 Sample Users (10 Ready to Test)

### Normal Queries (AI Handles Automatically)
1. **Aarav Mehta** - "Where is my order 101?"
2. **Sonali Rao** - "How long does shipping take? Order 202?"
3. **Harsh Patel** - "Can you track order 303?"
4. **Neel Kulkarni** - "I forgot my password"
5. **Priyanka Singh** - "Check order 5678"
6. **Riya Joshi** - "Can you help track order 707?"
7. **Tamanna Gupta** - "Warranty for order 999?"

### Escalation Cases (Marked for Human Review)
8. **Kavya Reddy** - "I'm upset! Charged twice! Order 404!"
9. **Vikram Desai** - "Package damaged! Destroyed!"
10. **Aditya Sharma** - "Full refund! Fraud!"

---

## 🧪 Test Commands (Copy & Paste)

### Get All Tickets
```bash
curl http://localhost:8080/api/tickets
```

### Get Single Ticket
```bash
curl http://localhost:8080/api/tickets/1
```

### Create New Ticket (Test AI Response)
```bash
curl -X POST http://localhost:8080/api/tickets -H "Content-Type: application/json" -d "{\"name\":\"Test User\",\"orderId\":\"101\",\"subject\":\"Order Status\",\"query\":\"Where is my order 101?\"}"
```

---

## 📊 Database Info

**Database:** H2 (In-Memory)  
**Location:** RAM (Fast, cleared on restart)  
**Tables:** users, tickets, messages  
**Records:** 10 users + 10 tickets + 20 messages  

### H2 Console Login
- **URL:** `http://localhost:8080/h2-console`
- **JDBC URL:** `jdbc:h2:mem:mindx_db`
- **User:** `sa`
- **Password:** (leave blank)

### Sample SQL Queries
```sql
-- See all users
SELECT * FROM users;

-- See all tickets
SELECT * FROM tickets;

-- See all messages
SELECT * FROM messages;

-- Count escalated tickets
SELECT COUNT(*) FROM tickets WHERE status = 'NEEDS_HUMAN';

-- Get conversation for ticket 1
SELECT * FROM messages WHERE ticket_id = 1;
```

---

## ✓ Order IDs That Have Tracking Data

| Order ID | Status | Details |
|----------|--------|---------|
| 101 | In Transit | Mumbai Hub |
| 202 | Delivered | Bengaluru |
| 303 | Out for Delivery | Delhi |
| 404 | Processing | Pune |
| 505 | Shipped | Chennai |
| 606 | Delivered | Kolkata |
| 707 | In Transit | Hyderabad |
| 808 | Out for Delivery | Jaipur |
| 5678 | In Transit | Ahmedabad |

---

## 📁 Important Files

| File | Purpose |
|------|---------|
| `WORKING_INPUT_LIST.md` | Complete user list + details |
| `QUICK_TEST.md` | API test commands |
| `DATABASE_SCHEMA.md` | DB structure + queries |
| `READY_FOR_DEMO.md` | Full setup guide |

---

## 🎯 What Happens When App Starts

```
1. Spring Boot initializes
2. DataInitializer runs (automatically)
3. Creates 10 sample users in DB
4. Creates 10 tickets with AI responses
5. Populates 20 messages
6. App ready at http://localhost:8080
```

---

## 🔧 Troubleshooting

**App won't start?**
```bash
taskkill /F /IM java.exe
mvnw.cmd spring-boot:run
```

**Port 8080 in use?**
```bash
netstat -ano | findstr :8080
taskkill /PID [PID_NUMBER] /F
```

**No data showing?**
- Check terminal for "✅ Sample Data Initialized"
- Restart the app

---

## 💬 Escalation Keywords (Auto-Detected)

These words trigger human escalation:
- angry, upset, furious, complaint
- damage, destroy, broken, fraud
- refund, charge, money, payment
- help, urgent, ASAP

---

## 📊 Statistics

| Metric | Count |
|--------|-------|
| Sample Users | 10 |
| Sample Tickets | 10 |
| Sample Messages | 20 |
| Pre-loaded Orders | 9 |
| Escalated Tickets | 3 |
| Auto-Resolved | 7 |

---

## 🎬 Demo Flow

1. **Start App** → `mvnw.cmd spring-boot:run`
2. **Open Browser** → `http://localhost:8080`
3. **Show Tickets** → Scroll to see all 10
4. **Explain AI** → Click ticket to see conversation
5. **Show Admin** → Visit `/admin` to see dashboard
6. **Show Database** → Visit `/h2-console` to see data
7. **Test New Query** → Submit new order and see response

---

## 📞 Quick Links

- **GitHub:** [Your Repo URL]
- **Documentation:** `SAMPLE_DATA.md`, `API_REFERENCE.md`
- **Database Console:** `http://localhost:8080/h2-console`
- **API Docs:** `http://localhost:8080/api/tickets`

---

## ⚡ Performance Notes

- **Startup:** 5-10 seconds
- **Query Response:** <500ms
- **Database Operations:** <100ms (in-memory)
- **AI Response Generation:** ~300ms

---

## 🎓 For Interview

**Opens with:**
> "This is a full-stack AI customer support application. It handles order tracking, ticket management, and intelligent escalation."

**Key Points:**
- 10 users pre-loaded for demo
- AI responding with real tracking data
- Escalation system working for urgent issues
- Complete database integration
- Built with Spring Boot + React + H2

**Closes with:**
> "The system demonstrates practical skills in backend development, AI integration, and database management."

---

## ✅ Verification (3 Quick Tests)

```bash
# Test 1: App running
curl http://localhost:8080 | find "Service AI" && echo ✓ OK

# Test 2: Sample data
curl http://localhost:8080/api/tickets | find "Aarav" && echo ✓ OK

# Test 3: AI working
curl -X POST http://localhost:8080/api/tickets -H "Content-Type: application/json" -d "{\"name\":\"Test\",\"orderId\":\"101\",\"subject\":\"T\",\"query\":\"Where?\"}" | find "Mumbai" && echo ✓ OK
```

All 3: **GREEN** ✅ = Ready to present!

---

## 🎁 Bonus Commands

**Kill all Java processes:**
```bash
taskkill /F /IM java.exe
```

**Check if app is running:**
```bash
curl http://localhost:8080
```

**View last app logs:**
```bash
# Logs appear in the terminal where app is running
```

**Stop the app:**
```
In terminal: Press Ctrl+C
```

---

**Everything is ready! Start the app and go live.** 🚀
