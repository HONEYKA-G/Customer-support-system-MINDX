# API Endpoints & Data Flow - MindX Service AI

## Backend REST API Endpoints

All endpoints are hosted at `http://localhost:8081/api/tickets`

### 1. Create a New Ticket (POST)

**Endpoint**: `POST /api/tickets`

**What it does**:
- Customer submits chat message
- Backend creates ticket + messages
- AI processes and responds

**Request (From Chat Form)**:
```json
{
  "name": "Priya Sharma",
  "subject": "Delivery Time",
  "query": "How long does standard shipping take?"
}
```

**Response (What customer sees)**:
```json
{
  "id": 1,
  "userId": 1,
  "customerName": "Priya Sharma",
  "subject": "Delivery Time",
  "query": "How long does standard shipping take?",
  "status": "OPEN",
  "createdAt": "2026-04-08T10:15:23",
  "aiResponse": "Delivery times vary by location. Standard shipping takes 3-5 business days...",
  "messages": [
    {
      "id": 1,
      "sender": "USER",
      "message": "How long does standard shipping take?",
      "timestamp": "2026-04-08T10:15:23"
    },
    {
      "id": 2,
      "sender": "AI",
      "message": "Delivery times vary by location...",
      "timestamp": "2026-04-08T10:15:28"
    }
  ]
}
```

**Database Changes**:
```
INSERT INTO users (name) VALUES ('Priya Sharma');                    → user_id = 1
INSERT INTO tickets (user_id, subject, query, status, created_at)   → ticket_id = 1
INSERT INTO messages (ticket_id, sender, message, timestamp)         → 2 messages
```

---

### 2. Get All Tickets (GET)

**Endpoint**: `GET /api/tickets`

**What it does**:
- Admin dashboard fetches all tickets
- Returns list with latest first

**Response**:
```json
[
  {
    "id": 5,
    "userId": 5,
    "customerName": "Vikram Gupta",
    "subject": "Billing Problem",
    "query": "I was charged twice!",
    "status": "NEEDS_HUMAN",
    "createdAt": "2026-04-08T11:15:33",
    "messages": [...]
  },
  {
    "id": 4,
    "userId": 4,
    "customerName": "Neha Singh",
    "subject": "Product Quality",
    "query": "Item is damaged",
    "status": "OPEN",
    "createdAt": "2026-04-08T11:00:12",
    "messages": [...]
  },
  {
    "id": 3,
    "userId": 3,
    "customerName": "Amit Patel",
    "subject": "Account Issue",
    "query": "Can't reset password",
    "status": "NEEDS_HUMAN",
    "createdAt": "2026-04-08T10:45:00",
    "messages": [...]
  }
]
```

**Database Query**:
```sql
SELECT t.*, u.name FROM tickets t
LEFT JOIN users u ON t.user_id = u.id
ORDER BY t.created_at DESC
```

---

### 3. Get Single Ticket Details (GET)

**Endpoint**: `GET /api/tickets/{id}`

**Example**: `GET /api/tickets/2`

**What it does**:
- Fetches full conversation for one ticket
- Used when admin clicks a ticket in list

**Response**:
```json
{
  "id": 2,
  "userId": 2,
  "customerName": "Rajesh Kumar",
  "subject": "Order Complaint",
  "query": "I am VERY angry! This order is a FRAUD and I want a REFUND immediately!",
  "status": "NEEDS_HUMAN",
  "createdAt": "2026-04-08T10:30:45",
  "messages": [
    {
      "id": 3,
      "sender": "USER",
      "message": "I am VERY angry! This order is a FRAUD...",
      "timestamp": "2026-04-08T10:30:45"
    },
    {
      "id": 4,
      "sender": "AI",
      "message": "Your query has been flagged for review by our support team...",
      "timestamp": "2026-04-08T10:30:50"
    },
    {
      "id": 5,
      "sender": "ADMIN",
      "message": "Refund processed. Your refund of $49.99 has been initiated...",
      "timestamp": "2026-04-08T11:00:00"
    }
  ]
}
```

**Database Query**:
```sql
SELECT t.* FROM tickets t WHERE t.id = 2;
SELECT m.* FROM messages m WHERE m.ticket_id = 2 ORDER BY timestamp ASC;
SELECT u.name FROM users u WHERE u.id = 2;
```

---

### 4. Update Ticket Status (PATCH)

**Endpoint**: `PATCH /api/tickets/{id}/status?status=RESOLVED`

**Example**: `PATCH /api/tickets/2/status?status=RESOLVED`

**What it does**:
- Admin changes ticket status
- Triggers from dropdown in admin dashboard

**Request**:
```
Status: RESOLVED (sent as query parameter)
```

**Response**:
```json
{
  "id": 2,
  "userId": 2,
  "customerName": "Rajesh Kumar",
  "subject": "Order Complaint",
  "status": "RESOLVED",  ← Changed!
  "createdAt": "2026-04-08T10:30:45",
  "messages": [...]
}
```

**Database Update**:
```sql
UPDATE tickets SET status = 'RESOLVED' WHERE id = 2;
```

---

## Complete Data Flow Example

### Step-by-Step: Customer Submits Chat Message

```
┌─────────────────────────────────────────────────────────────────┐
│ STEP 1: CUSTOMER FILLS CHAT FORM                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ [Chat Page - Browser]                                           │
│ Your name:     "Rajesh Kumar"                                   │
│ Subject:       "Missing Order"                                  │
│ Message:       "Where is my order?"                             │
│                                                                 │
│ [Clicks: Send Message]                                          │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ STEP 2: API REQUEST SENT TO BACKEND                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ POST http://localhost:8081/api/tickets                          │
│                                                                 │
│ Body (JSON):                                                    │
│ {                                                               │
│   "name": "Rajesh Kumar",                                       │
│   "subject": "Missing Order",                                   │
│   "query": "Where is my order?"                                 │
│ }                                                               │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ STEP 3: BACKEND PROCESSES REQUEST                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ TicketController @PostMapping:                                  │
│   → TicketService.createTicket(request)                         │
│   → Called with name, subject, query                            │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ STEP 4: DATABASE INSERTS                                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ A) Check if user exists in users table:                         │
│    SELECT * FROM users WHERE name = 'Rajesh Kumar';             │
│    → Not found, so:                                             │
│    INSERT INTO users (name) VALUES ('Rajesh Kumar');            │
│    → Returns: user_id = 1                                       │
│                                                                 │
│ B) Create ticket:                                               │
│    INSERT INTO tickets                                          │
│    (user_id, subject, query, status, created_at)                │
│    VALUES (1, 'Missing Order', 'Where is my order?',            │
│            'OPEN', NOW());                                      │
│    → Returns: ticket_id = 1                                     │
│                                                                 │
│ C) Check for escalation keywords:                               │
│    "Where is my order?" → No keywords detected                  │
│    → Status remains: OPEN                                       │
│                                                                 │
│ D) Store user message:                                          │
│    INSERT INTO messages                                         │
│    (ticket_id, sender, message, timestamp)                      │
│    VALUES (1, 'USER', 'Where is my order?', NOW());             │
│    → Returns: message_id = 1                                    │
│                                                                 │
│ E) Get AI response:                                             │
│    AiService.getAiResponse('Where is my order?')                │
│    → Returns: "Your order is in transit..."                    │
│                                                                 │
│ F) Store AI message:                                            │
│    INSERT INTO messages                                         │
│    (ticket_id, sender, message, timestamp)                      │
│    VALUES (1, 'AI', 'Your order is in transit...', NOW());      │
│    → Returns: message_id = 2                                    │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ STEP 5: API RESPONSE SENT BACK                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ HTTP 200 OK (JSON Response)                                     │
│ {                                                               │
│   "id": 1,                                                      │
│   "userId": 1,                                                  │
│   "customerName": "Rajesh Kumar",                               │
│   "subject": "Missing Order",                                   │
│   "query": "Where is my order?",                                │
│   "status": "OPEN",                                             │
│   "createdAt": "2026-04-08T10:15:23",                           │
│   "aiResponse": "Your order is in transit...",                  │
│   "messages": [                                                 │
│     {                                                           │
│       "id": 1,                                                  │
│       "sender": "USER",                                         │
│       "message": "Where is my order?",                          │
│       "timestamp": "2026-04-08T10:15:23"                        │
│     },                                                          │
│     {                                                           │
│       "id": 2,                                                  │
│       "sender": "AI",                                           │
│       "message": "Your order is in transit...",                 │
│       "timestamp": "2026-04-08T10:15:28"                        │
│     }                                                           │
│   ]                                                             │
│ }                                                               │
└─────────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────┐
│ STEP 6: FRONTEND DISPLAYS RESPONSE                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ [Chat Page - Browser]                                           │
│                                                                 │
│ ┌─ Ticket #1 ─────────────────────────────────────────────┐   │
│ │                                                          │   │
│ │ Missing Order                            🟦 OPEN        │   │
│ │ Rajesh Kumar • 2026-04-08 10:15:23                      │   │
│ │                                                          │   │
│ │ USER (10:15:23)                                         │   │
│ │ "Where is my order?"                                    │   │
│ │                                                          │   │
│ │ AI (10:15:28)                                           │   │
│ │ "Your order is in transit..."                           │   │
│ │                                                          │   │
│ └──────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## What Gets Stored Where

### Chat Form Input
```
Frontend (React)
    ↓
name: "Rajesh Kumar"
subject: "Missing Order"
query: "Where is my order?"
    ↓
API Request: POST /api/tickets
    ↓
Backend (Spring)
    ↓
Database (H2 RAM)
```

### Database State After Request
```
users Table:
  1 | Rajesh Kumar

tickets Table:
  1 | 1 | Missing Order | Where is my order? | OPEN | 2026-04-08 10:15:23

messages Table:
  1 | 1 | USER | Where is my order? | 2026-04-08 10:15:23
  2 | 1 | AI   | Your order is in transit... | 2026-04-08 10:15:28
```

---

## Keyword Detection Flow

When customer submits query with escalation keywords:

```
Query: "I want a REFUND because this product is TERRIBLE!"

Backend receives → EscalationService.requiresHumanEscalation(query)

Check keywords:
  ✓ "refund" found → MATCH
  ✓ "terrible" found → MATCH

Result: escalation = true
    ↓
Set status = "NEEDS_HUMAN"
    ↓
Store ticket with status = NEEDS_HUMAN
    ↓
AI response: "Your query has been flagged for human review..."
```

---

## JSON Response Examples

### Ticket in OPEN Status
```json
{
  "id": 1,
  "status": "OPEN",
  "messages": [
    {"sender": "USER", "message": "Normal query"},
    {"sender": "AI", "message": "AI response"}
  ]
}
```

### Ticket in NEEDS_HUMAN Status
```json
{
  "id": 2,
  "status": "NEEDS_HUMAN",
  "messages": [
    {"sender": "USER", "message": "I want a REFUND!"},
    {"sender": "AI", "message": "Flagged for human review..."}
  ]
}
```

### Ticket in RESOLVED Status
```json
{
  "id": 3,
  "status": "RESOLVED",
  "messages": [
    {"sender": "USER", "message": "Issue description"},
    {"sender": "AI", "message": "Initial response"},
    {"sender": "ADMIN", "message": "Issue resolved"}
  ]
}
```

---

## Error Responses

### Missing Required Field
```json
{
  "timestamp": "2026-04-08T10:15:23",
  "status": 400,
  "error": "Bad Request",
  "message": "Query must not be empty."
}
```

### Ticket Not Found
```json
{
  "timestamp": "2026-04-08T10:15:23",
  "status": 500,
  "error": "Internal Server Error",
  "message": "Ticket not found: 999"
}
```

---

## Performance Notes

- **User lookup**: `SELECT * FROM users WHERE name = ?` (instant)
- **Ticket creation**: `INSERT` (instant)
- **Message creation**: 2x `INSERT` (instant)
- **AI response time**: ~300-500ms (OpenAI API or mock)
- **Fetch all tickets**: `SELECT` + `LEFT JOIN` (instant)
- **Fetch ticket detail**: `SELECT` + `JOIN` (instant)

---

## Security Notes

- **No authentication** in current version (demo only)
- **CORS enabled** for local development
- **Exception handling** returns formatted JSON errors
- **SQL Injection**: Protected by JPA (parameterized queries)
- **Input validation**: Query, name check for empty values
