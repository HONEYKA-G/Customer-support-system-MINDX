# 🧪 Quick Test Commands - Copy & Paste Ready

## Get All Tickets (View all 10 sample tickets)
```bash
curl http://localhost:8080/api/tickets
```

## Get Ticket #1 (Aarav Mehta's Order Status)
```bash
curl http://localhost:8080/api/tickets/1
```

## Get Ticket #4 (Escalated - Kavya Reddy's Problem)
```bash
curl http://localhost:8080/api/tickets/4
```

---

## Test New Query - Tracking Request

**Copy this exact command:**
```bash
curl -X POST http://localhost:8080/api/tickets ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Your Name\",\"orderId\":\"101\",\"subject\":\"Track Order\",\"query\":\"Where is my order 101?\"}"
```

**Expected Response:** Order tracking details with status "In Transit"

---

## Test New Query - Escalation Trigger

**Copy this exact command:**
```bash
curl -X POST http://localhost:8080/api/tickets ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Angry Customer\",\"orderId\":\"999\",\"subject\":\"Complaint\",\"query\":\"I am very upset and want a refund immediately!\"}"
```

**Expected Response:** Escalation message, Ticket status: NEEDS_HUMAN

---

## Test New Query - General Help

**Copy this exact command:**
```bash
curl -X POST http://localhost:8080/api/tickets ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"John Doe\",\"orderId\":\"505\",\"subject\":\"Help\",\"query\":\"How long does standard shipping take?\"}"
```

**Expected Response:** Generic helpful response

---

## Test Specific Order Tracking

Try these Order IDs for different responses:

**Order 101 (In Transit):**
```bash
curl -X POST http://localhost:8080/api/tickets ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Customer\",\"orderId\":\"101\",\"subject\":\"T\",\"query\":\"Where is order 101?\"}"
```

**Order 202 (Delivered):**
```bash
curl -X POST http://localhost:8080/api/tickets ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Customer\",\"orderId\":\"202\",\"subject\":\"T\",\"query\":\"Where is order 202?\"}"
```

**Order 303 (Out for Delivery):**
```bash
curl -X POST http://localhost:8080/api/tickets ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Customer\",\"orderId\":\"303\",\"subject\":\"T\",\"query\":\"Where is order 303?\"}"
```

---

## Database Queries (H2 Console)

**Count All Tickets:**
```sql
SELECT COUNT(*) as TOTAL_TICKETS FROM tickets;
```

**Count Escalated Tickets:**
```sql
SELECT COUNT(*) as ESCALATED FROM tickets WHERE status = 'NEEDS_HUMAN';
```

**See All Users:**
```sql
SELECT * FROM users;
```

**See All Messages for Ticket #1:**
```sql
SELECT * FROM messages WHERE ticket_id = 1 ORDER BY timestamp ASC;
```

**See Latest 5 Tickets:**
```sql
SELECT * FROM tickets ORDER BY created_at DESC LIMIT 5;
```

---

## One-Shot Testing Script

**Run this entire sequence to verify everything works:**

```bash
echo ========================================
echo 1. Check app is running...
curl -s http://localhost:8080 | find "Service AI" && echo ✓ App is live

echo.
echo 2. Get all tickets...
curl -s http://localhost:8080/api/tickets | find "id" && echo ✓ Tickets found

echo.
echo 3. Test tracking query (Order 101)...
curl -s -X POST http://localhost:8080/api/tickets ^
  -H "Content-Type: application/json" ^
  -d "{\"name\":\"Test\",\"orderId\":\"101\",\"subject\":\"T\",\"query\":\"Where is my order?\"}" | find "In Transit" && echo ✓ Tracking works

echo.
echo ========================================
echo ✅ All tests passed!
echo ========================================
```

---

## Natural Query Examples (What Real Users Will Ask)

### Tracking Queries (AI will provide order info):
- "Where is my order?"
- "Can you track order 101?"
- "What's the status of my package?"
- "When will my 303 order arrive?"
- "My order 505 - where is it?"
- "Is my shipment on the way?"
- "Check my delivery status"

### Escalation Queries (Will be flagged for human):
- "This is unacceptable! Where is my order?!"
- "I'm very upset about order 999!"
- "I demand a refund!"
- "The item arrived damaged!"
- "You charged me twice!"
- "This is fraud!"
- "I'm furious about this!"

### General Queries (Generic responses):
- "What's your customer service?"
- "Do you offer warranties?"
- "How do returns work?"
- "Can I cancel my order?"
- "I forgot my password"

---

## What Each Response Means

### ✓ OPEN Status
Task: AI handled it automatically  
Example: User asks for tracking → AI provides order details  
Action: No admin needed

### ⚠️ NEEDS_HUMAN Status
Task: AI detected escalation/complaint  
Example: User angry about product quality  
Action: **Admin must review and respond**

### ✅ RESOLVED Status
Task: Admin marked as resolved  
Example: Refund issued, complaint addressed  
Action: Done

---

## Performance Notes

- App startup: ~5-10 seconds
- Sample data initialization: Automatic
- Each query response: <500ms
- Database queries: In-memory (instant)
- No external API calls (unless OpenAI key configured)

---

## Troubleshooting

**App won't start?**
```bash
taskkill /F /IM java.exe
# Then: mvnw.cmd spring-boot:run
```

**Port 8080 in use?**
```bash
netstat -ano | findstr :8080
# Kill the PID that appears
```

**Data not showing?**
- Restart the app (data re-initializes on startup)
- Check H2 Console at http://localhost:8080/h2-console

**AI not responding?**
- Make sure Order ID is valid (101, 202, 303, 404, 505, 5678, etc.)
- Check logs for errors

---

## Success Indicators

✓ See "✅ Sample Data Initialized Successfully!" in terminal  
✓ 10 tickets appear in database  
✓ Tracking queries return order details  
✓ Escalation keywords trigger human flag  
✓ Admin dashboard shows mixed OPEN/NEEDS_HUMAN tickets  

Everything working = **Your demo is ready!** 🎉
