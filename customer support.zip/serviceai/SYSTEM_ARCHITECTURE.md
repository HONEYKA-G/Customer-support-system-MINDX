# MindX Service AI - Complete System Architecture

## System Overview

```
                              ┌─────────────────┐
                              │   CUSTOMER      │
                              │   (Web Browser) │
                              └────────┬────────┘
                                       │
                         ┌─────────────┴─────────────┐
                         │                           │
                    ┌────▼─────┐              ┌─────▼────┐
                    │   CHAT   │              │  ADMIN   │
                    │   PAGE   │              │DASHBOARD │
                    └────┬─────┘              └─────┬────┘
                         │                          │
                         └────────────┬─────────────┘
                                      │
                         ┌────────────▼────────────┐
                         │  REACT FRONTEND         │
                         │  (Port 5173)            │
                         │  - Chat UI              │
                         │  - Admin Dashboard      │
                         └────────────┬────────────┘
                                      │
                        ┌─────────────┴──────────────┐
                        │  HTTP/JSON API Proxy       │
                        │  localhost:8081/api        │
                        └─────────────┬──────────────┘
                                      │
                    ┌─────────────────▼──────────────────┐
                    │  SPRING BOOT BACKEND              │
                    │  (Port 8081)                       │
                    ├──────────────────────────────────┤
                    │ Controllers:                       │
                    │ - TicketController                 │
                    │   POST /api/tickets                │
                    │   GET /api/tickets                 │
                    │   GET /api/tickets/{id}            │
                    │   PATCH /api/tickets/{id}/status   │
                    │                                    │
                    │ Services:                          │
                    │ - TicketService                    │
                    │ - AiService                        │
                    │ - EscalationService                │
                    │ - UserRepository                   │
                    │                                    │
                    │ Exception Handling:                │
                    │ - GlobalExceptionHandler           │
                    └─────────────┬──────────────────────┘
                                  │
                    ┌─────────────▼──────────────┐
                    │ H2 IN-MEMORY DATABASE      │
                    │ (Ram Based)                │
                    ├────────────────────────────┤
                    │ Tables:                    │
                    │ • users                    │
                    │ • tickets                  │
                    │ • messages                 │
                    └────────────────────────────┘
```

---

## Data Storage Flow

```
┌──────────────┐
│ CUSTOMER     │
│ Fills Chat   │
│ Form         │
└──────┬───────┘
       │
       ├─ Name: "Rajesh Kumar"
       ├─ Subject: "Missing Order"
       └─ Query: "Where is my item?"
       │
       ▼
┌──────────────────────────────────┐
│ BACKEND RECEIVES REQUEST         │
│ POST /api/tickets                │
└──────┬───────────────────────────┘
       │
       ├─ STEP 1: Find/Create User
       │  [users.name = "Rajesh Kumar"]
       │  → user_id = 1
       │
       ├─ STEP 2: Check for Escalation
       │  [Query has "refund"? "complaint"? "angry"?]
       │  → No → status = OPEN (AI will respond)
       │  → Yes → status = NEEDS_HUMAN (human review)
       │
       ├─ STEP 3: Create Ticket
       │  INSERT INTO tickets
       │  (user_id=1, subject, query, status, created_at)
       │  → ticket_id = 1
       │
       ├─ STEP 4: Store User Message
       │  INSERT INTO messages
       │  (ticket_id=1, sender=USER, message=query)
       │  → message_id = 1
       │
       ├─ STEP 5: Get AI Response
       │  AiService.getAiResponse(query)
       │  → "Your order is in transit..."
       │
       ├─ STEP 6: Store AI Message
       │  INSERT INTO messages
       │  (ticket_id=1, sender=AI, message=response)
       │  → message_id = 2
       │
       └─ STEP 7: Return to Frontend
          with ticket_id, messages, status
          │
          ▼
       ┌──────────────────┐
       │ CUSTOMER SEES    │
       │ Ticket & Chat    │
       │ with AI response │
       └──────────────────┘
```

---

## Database Tables

### 1. USERS Table
```
┌────┬────────────────────┐
│ id │ name               │
├────┼────────────────────┤
│ 1  │ Rajesh Kumar       │
│ 2  │ Priya Sharma       │
│ 3  │ Amit Patel         │
└────┴────────────────────┘

Purpose: Track unique customers
Size: ~1 KB per customer
Lifetime: From first ticket until server stops
```

### 2. TICKETS Table
```
┌────┬────────┬──────────────────┬──────────────────┬────────────┬──────────────────────┐
│ id │user_id│ subject          │ query            │ status     │ created_at           │
├────┼────────┼──────────────────┼──────────────────┼────────────┼──────────────────────┤
│ 1  │ 1     │ Missing Order    │ Where is my...   │ OPEN       │ 2026-04-08 10:15:23 │
│ 2  │ 2     │ Refund Request   │ I want my...     │ NEEDS_HUMAN│ 2026-04-08 10:20:45 │
│ 3  │ 3     │ Product Quality  │ Item is...       │ RESOLVED   │ 2026-04-08 09:00:00 │
└────┴────────┴──────────────────┴──────────────────┴────────────┴──────────────────────┘

Purpose: Store support tickets
Each Row: ~500 bytes
Lifetime: From ticket creation until server stops

Status Legend:
- OPEN: AI can respond, no human needed yet
- NEEDS_HUMAN: Escalated, human review required
- RESOLVED: Ticket closed, issue addressed
```

### 3. MESSAGES Table
```
┌────┬────────────┬────────┬──────────────────────────────────────┬──────────────────────┐
│ id │ ticket_id  │ sender │ message                              │ timestamp            │
├────┼────────────┼────────┼──────────────────────────────────────┼──────────────────────┤
│ 1  │ 1          │ USER   │ Where is my order?                   │ 2026-04-08 10:15:23 │
│ 2  │ 1          │ AI     │ Your order is in transit...          │ 2026-04-08 10:15:28 │
│ 3  │ 2          │ USER   │ I want my money back                 │ 2026-04-08 10:20:45 │
│ 4  │ 2          │ AI     │ Your query flagged for human review  │ 2026-04-08 10:20:50 │
│ 5  │ 2          │ ADMIN  │ Refund approved, check email         │ 2026-04-08 11:00:00 │
└────┴────────────┴────────┴──────────────────────────────────────┴──────────────────────┘

Purpose: Store chat messages for each ticket
Each Row: ~200 bytes per message
Lifetime: From message creation until server stops

Sender Types:
- USER: Customer message
- AI: Automated response
- ADMIN: Human agent response
```

---

## Complete Customer Journey

### Journey Flow Diagram

```
Customer Opens Chat Page
   ↓
┌─ Scenarios ─────────────────────────────────────────────────┐
│                                                              │
├─ Scenario 1: Normal Query (AI Responds)                     │
│  ├─ Input: "How long for shipping?"                         │
│  ├─ No escalation keywords                                  │
│  ├─ Status: OPEN                                            │
│  ├─ AI processes & responds                                 │
│  ├─ Database: 1 ticket + 2 messages (USER + AI)             │
│  └─ Customer sees immediate AI response                     │
│                                                              │
├─ Scenario 2: Escalation (Human Review)                      │
│  ├─ Input: "I want a REFUND! This is terrible!"             │
│  ├─ Escalation keywords found: "refund", "terrible"         │
│  ├─ Status: NEEDS_HUMAN                                     │
│  ├─ AI flags for human review                               │
│  ├─ Database: 1 ticket + 2 messages (USER + AI flag)        │
│  ├─ Admin sees in dashboard with yellow badge               │
│  ├─ Admin reviews & responds                                │
│  ├─ Database: Additional message (ADMIN response)           │
│  └─ Ticket can be marked RESOLVED                           │
│                                                              │
└──────────────────────────────────────────────────────────────┘
   ↓
Customer waits for response in Chat Page
   ↓
Admin sees in Dashboard (for NEEDS_HUMAN tickets)
   ↓
Admin can:
   • View full conversation
   • Change status (OPEN → RESOLVED)
   • Add notes (optional)
   ↓
Customer conversation history preserved
   ↓
Server stops → All data cleared from RAM
```

---

## Escalation Logic

### Keywords That Trigger NEEDS_HUMAN Status

```
Refund Keywords:
- "refund"
- "money back"
- "return"

Complaint Keywords:
- "angry"
- "furious"
- "upset"
- "terrible"
- "awful"
- "hate"

Fraud Keywords:
- "fraud"
- "scam"
- "cheat"

Legal Keywords:
- "sue"
- "lawyer"
- "legal"
```

### Escalation Flow

```
Customer Query
   ↓
Backend checks:
   ├─ Convert to lowercase
   ├─ Check each keyword
   └─ If ANY match → ESCALATE
   ↓
NO MATCH → status = OPEN
   ├─ Message: AI response
   └─ Backend: Uses AiService
   ↓
MATCH → status = NEEDS_HUMAN
   ├─ Message: "Flagged for human review"
   └─ Backend: Skips AI, logs escalation
   ↓
Admin sees in dashboard
   ├─ Yellow badge: NEEDS_HUMAN
   ├─ Can read full conversation
   └─ Can provide human response
```

---

## Information Storage Examples

### Example 1: Simple Query
```
Customer Input:
├─ Name: "Priya Sharma"
├─ Subject: "Delivery Status"
└─ Query: "How do I track my order?"

Stored In Database:
├─ users: id=1, name="Priya Sharma"
├─ tickets: id=1, user_id=1, subject="Delivery Status",
│           query="How do I track my order?", status="OPEN"
├─ messages (USER): ticket_id=1, sender="USER",
│                   message="How do I track my order?"
└─ messages (AI): ticket_id=1, sender="AI",
                  message="Please provide your order number..."
```

### Example 2: Escalation Case
```
Customer Input:
├─ Name: "Rajesh Kumar"
├─ Subject: "Complaint"
└─ Query: "This order is a FRAUD! I want a REFUND now!"

Backend Detection:
├─ Found keyword: "FRAUD"
├─ Found keyword: "REFUND"
└─ Action: Escalate to NEEDS_HUMAN

Stored In Database:
├─ users: id=2, name="Rajesh Kumar"
├─ tickets: id=2, user_id=2, subject="Complaint",
│           query="This order is a FRAUD!...", 
│           status="NEEDS_HUMAN" ← Escalated!
├─ messages (USER): ticket_id=2, sender="USER",
│                   message="This order is a FRAUD!..."
├─ messages (AI): ticket_id=2, sender="AI",
│                 message="Your query has been flagged..."
└─ [Admin can now respond with ADMIN message]
```

---

## Data Lifetime

```
Backend Server Running
   ├─ Customer submits chat ─┐
   │  → Data in RAM only      └─► Accessible immediately
   │  → Shows in dashboard       
   │  → Persists in memory       
   │                             
   ├─ Admin updates status   
   │  → Updates RAM only      └─► Changes instant
   │  → No disk saved        
   │                          
   └─ Multiple customers     
      → All data in RAM      └─► Multi-client support
      → No collisions        

Server Stops (Ctrl+C)
   │
   ├─ RAM cleared
   ├─ All data lost
   └─ Fresh database on restart
```

---

## Real Data Flow Diagram

```
Frontend Form Input
    │
    │ HTTP POST
    │ JSON: {name, subject, query}
    │
    ▼
Spring Boot Controller
    │
    ├─► Service Layer
    │   ├─ UserRepository.findByName()
    │   ├─ TicketRepository.save()
    │   ├─ EscalationService.check()
    │   ├─ AiService.respond()
    │   └─ MessageRepository.save()
    │
    └─► H2 Database (In RAM)
        ├─ INSERT INTO users
        ├─ INSERT INTO tickets
        └─ INSERT INTO messages (2 records)
        
    │
    │ Response JSON
    │ {id, status, messages[]}
    │
    ▼
Frontend Display
    │
    ├─ Chat Page shows:
    │  ├─ Ticket ID
    │  ├─ Status badge
    │  └─ Messages (USER + AI)
    │
    └─ Admin Dashboard shows:
       ├─ Ticket list
       ├─ Conversation thread
       └─ Status update dropdown
```

---

## Key Takeaways

| Aspect | Details |
|--------|---------|
| **Where Data Stored** | H2 in-memory database (RAM) | 
| **How Long** | Until server stops |
| **Database Setup** | Zero installation needed |
| **Tables** | 3 tables (users, tickets, messages) |
| **Data Entry** | Chat form → Backend → Database |
| **Data Retrieval** | Dashboard queries → Display |
| **Escalation** | Keyword detection → status = NEEDS_HUMAN |
| **Sample Data** | Each customer interaction creates 2+ messages |

---

## Quick Start Test

### Test Flow:

1. **Backend Running**: `mvn spring-boot:run` (port 8081)
2. **Frontend Running**: `npm run dev` (port 5173)
3. **Open Browser**: `http://localhost:5173`
4. **Fill Chat Form**:
   - Name: "Your Name"
   - Subject: "Test"
   - Message: "Hello"
5. **Backend Stores**:
   - User record
   - Ticket record
   - 2 Message records
6. **See Response Immediately**
7. **Admin Dashboard Tab**: See your ticket in list
8. **Click Ticket**: See full conversation
9. **Change Status**: Click dropdown, select "RESOLVED"
10. **View H2 Console**: `http://localhost:8081/h2-console`
    - Run: `SELECT * FROM messages;`
    - See: All your messages in RAM

---

## Summary

```
MindX Service AI is a complete support system where:

1. Customers submit queries via chat
2. Backend stores data in H2 (RAM database)
3. AI processes & responds (or escalates)
4. Admins manage tickets in dashboard
5. All data lives in memory (temp for demo)
6. Tables: users, tickets, messages
7. Status: OPEN, NEEDS_HUMAN, RESOLVED
8. No external database needed!
```
