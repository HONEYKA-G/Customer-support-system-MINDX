import { useEffect, useState } from 'react';
import { fetchTickets } from '../services/api.js';

export default function AllTicketsPage() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadTickets();
  }, []);

  async function loadTickets() {
    setLoading(true);
    setError('');
    try {
      const data = await fetchTickets();
      setTickets(data || []);
    } catch (err) {
      setError('Unable to load tickets. Please ensure the backend is running.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <div className="section-header">
        <div>
          <h2>All Tickets</h2>
          <p>Review every customer case and filter status in one place.</p>
        </div>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="card table-card">
        <table className="table">
          <thead>
            <tr>
              <th>Ticket</th>
              <th>Customer</th>
              <th>Type</th>
              <th>Status</th>
              <th>Order</th>
              <th>Created</th>
            </tr>
          </thead>
          <tbody>
            {tickets.map((ticket) => (
              <tr key={ticket.id}>
                <td>#{ticket.id}</td>
                <td>{ticket.customerName || 'Guest'}</td>
                <td>{ticket.subject || ticket.query}</td>
                <td>
                  <span className={`status-pill status-${ticket.status}`}>
                    {ticket.status}
                  </span>
                </td>
                <td>{ticket.orderId || '-'}</td>
                <td>{new Date(ticket.createdAt).toLocaleString()}</td>
              </tr>
            ))}
            {tickets.length === 0 && !loading && (
              <tr>
                <td colSpan="6" className="empty-state">
                  No tickets found yet.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
