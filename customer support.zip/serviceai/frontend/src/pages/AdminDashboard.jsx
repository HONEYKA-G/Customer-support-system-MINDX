import { useEffect, useMemo, useState } from 'react';
import { fetchTickets, updateTicketStatus } from '../services/api.js';

const statusOptions = ['OPEN', 'NEEDS_HUMAN', 'RESOLVED'];

export default function AdminDashboard() {
  const [tickets, setTickets] = useState([]);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('ALL');

  useEffect(() => {
    loadTickets();
  }, []);

  async function loadTickets() {
    setLoading(true);
    setError('');
    try {
      const data = await fetchTickets();
      setTickets(data || []);
      if (!selectedTicket && data?.length) {
        setSelectedTicket(data[0]);
      }
    } catch (err) {
      setError('Could not load tickets. Is the backend running?');
    } finally {
      setLoading(false);
    }
  }

  async function handleStatusChange(ticketId, newStatus) {
    try {
      await updateTicketStatus(ticketId, newStatus);
      await loadTickets();
    } catch (err) {
      setError('Unable to update ticket status.');
    }
  }

  const counts = useMemo(() => {
    return {
      total: tickets.length,
      open: tickets.filter((ticket) => ticket.status === 'OPEN').length,
      needsHuman: tickets.filter((ticket) => ticket.status === 'NEEDS_HUMAN').length,
      resolved: tickets.filter((ticket) => ticket.status === 'RESOLVED').length,
    };
  }, [tickets]);

  const filteredTickets = useMemo(() => {
    return tickets.filter((ticket) => {
      const text = `${ticket.customerName || ''} ${ticket.subject || ''} ${ticket.query || ''}`.toLowerCase();
      if (filter !== 'ALL' && ticket.status !== filter) {
        return false;
      }
      return text.includes(search.toLowerCase());
    });
  }, [tickets, search, filter]);

  return (
    <div>
      <div className="dashboard-header">
        <div>
          <h2>Admin Dashboard</h2>
          <p>Manage support tickets, escalations, and overall system health.</p>
        </div>
      </div>

      <div className="dashboard-summary">
        <div className="summary-card chart-card">
          <span>Total tickets</span>
          <h3>{counts.total}</h3>
          <p>Live ticket volume from the support pipeline.</p>
        </div>
        <div className="summary-card summary-open">
          <span>Open</span>
          <h3>{counts.open}</h3>
          <p>Tickets awaiting AI or human review.</p>
        </div>
        <div className="summary-card summary-needs-human">
          <span>Needs human</span>
          <h3>{counts.needsHuman}</h3>
          <p>Priority escalations requiring action.</p>
        </div>
        <div className="summary-card summary-resolved">
          <span>Resolved</span>
          <h3>{counts.resolved}</h3>
          <p>Issues successfully closed.</p>
        </div>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="card admin-panel-card">
        <div className="admin-panel-header">
          <div>
            <h3>Recent Tickets</h3>
            <p>Click any ticket to review details and update its status.</p>
          </div>
          <div className="admin-panel-actions">
            <input
              type="text"
              placeholder="Search tickets..."
              value={search}
              onChange={(event) => setSearch(event.target.value)}
            />
            <select value={filter} onChange={(event) => setFilter(event.target.value)}>
              <option value="ALL">All statuses</option>
              {statusOptions.map((statusOption) => (
                <option key={statusOption} value={statusOption}>
                  {statusOption}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="admin-layout">
          <div className="ticket-list-card">
            {filteredTickets.map((ticket) => (
              <button
                type="button"
                key={ticket.id}
                className={`ticket-list-item ${selectedTicket?.id === ticket.id ? 'selected' : ''}`}
                onClick={() => setSelectedTicket(ticket)}
              >
                <div className="ticket-meta-row">
                  <span className="ticket-badge">#{ticket.id}</span>
                  <span className={`status-pill status-${ticket.status}`}>{ticket.status}</span>
                </div>
                <h4>{ticket.subject || ticket.query}</h4>
                <p>{ticket.customerName || 'Guest'} · {ticket.orderId ? `Order ${ticket.orderId}` : 'No order id'}</p>
              </button>
            ))}
            {filteredTickets.length === 0 && !loading && (
              <div className="empty-state">No tickets match this view.</div>
            )}
          </div>

          <div className="ticket-detail-card">
            {selectedTicket ? (
              <div>
                <div className="ticket-detail-header">
                  <div>
                    <span className="pill">Ticket {selectedTicket.id}</span>
                    <h3>{selectedTicket.subject || 'Support request'}</h3>
                    <p>{selectedTicket.query}</p>
                  </div>
                  <div>
                    <select
                      className="status-select"
                      value={selectedTicket.status}
                      onChange={(event) => handleStatusChange(selectedTicket.id, event.target.value)}
                    >
                      {statusOptions.map((option) => (
                        <option key={option} value={option}>{option}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="ticket-detail-meta">
                  <span>{selectedTicket.customerName || 'Guest'}</span>
                  <span>{new Date(selectedTicket.createdAt).toLocaleString()}</span>
                </div>

                {selectedTicket.orderId && (
                  <div className="tracking-card large-card">
                    <div className="tracking-label">Order ID</div>
                    <div>{selectedTicket.orderId}</div>
                  </div>
                )}

                {selectedTicket.trackingInfo && (
                  <div className="tracking-card large-card">
                    <div className="tracking-label">Tracking details</div>
                    <div>{selectedTicket.trackingInfo}</div>
                  </div>
                )}

                <div className="conversation">
                  {selectedTicket.messages?.map((message) => (
                    <div key={message.id} className="message-card admin-message-card">
                      <div className="speaker">{message.sender}</div>
                      <div>{message.message}</div>
                      <div className="small-text">{new Date(message.timestamp).toLocaleString()}</div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="empty-state">Select a ticket from the left panel to view conversation details.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
