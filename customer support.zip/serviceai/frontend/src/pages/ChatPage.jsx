import { useState } from 'react';
import { createTicket } from '../services/api.js';

export default function ChatPage() {
  const [name, setName] = useState('');
  const [subject, setSubject] = useState('');
  const [orderId, setOrderId] = useState('');
  const [message, setMessage] = useState('');
  const [ticket, setTicket] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(event) {
    event.preventDefault();
    if (!name.trim() || !message.trim()) {
      setError('Please enter your name and a message to continue.');
      return;
    }
    setError('');
    setLoading(true);

    try {
      const created = await createTicket({
        name: name.trim(),
        subject: subject.trim(),
        query: message.trim(),
        orderId: orderId.trim() || undefined,
      });
      setTicket(created);
      setMessage('');
    } catch (err) {
      setError(err.message || 'Unable to create ticket. Please make sure the backend is running.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <div className="section-header">
        <div>
          <h2>Customer Chat</h2>
          <p>Send your query and receive an AI-powered response instantly.</p>
        </div>
      </div>

      <form className="chat-form" onSubmit={handleSubmit}>
        <div className="input-row">
          <input
            type="text"
            placeholder="Your name"
            value={name}
            onChange={(event) => setName(event.target.value)}
            required
          />
          <input
            type="text"
            placeholder="Subject (optional)"
            value={subject}
            onChange={(event) => setSubject(event.target.value)}
          />
        </div>
        <div className="input-row">
          <input
            type="text"
            placeholder="Order ID (optional)"
            value={orderId}
            onChange={(event) => setOrderId(event.target.value)}
          />
          <button
            type="button"
            className="btn-secondary small-button"
            onClick={() => setOrderId('101')}
          >
            Use sample Order ID
          </button>
        </div>
        <textarea
          placeholder="Describe your issue"
          value={message}
          onChange={(event) => setMessage(event.target.value)}
          required
        />
        <div className="input-row">
          <button className="btn-primary" type="submit" disabled={loading}>
            {loading ? 'Submitting...' : 'Send Message'}
          </button>
        </div>
        {error && <div className="error-box">{error}</div>}
      </form>

      {ticket && (
        <div className="ticket-panel">
          <div className="ticket-card">
            <div className="ticket-header">
              <div>
                <div className="pill">Ticket {ticket.id}</div>
                <h3>{ticket.subject || 'New support request'}</h3>
              </div>
              <div className={`status-pill status-${ticket.status}`}>
                {ticket.status}
              </div>
            </div>
            <div className="ticket-meta">
              <span>{ticket.customerName || 'Guest'}</span>
              <span>{new Date(ticket.createdAt).toLocaleString()}</span>
            </div>
          </div>

          {ticket.trackingInfo && (
            <div className="tracking-card">
              <div className="tracking-label">Tracking details</div>
              <div>{ticket.trackingInfo}</div>
            </div>
          )}

          <div className="message-list">
            {ticket.messages?.map((msg) => (
              <div
                key={msg.id}
                className={`message-bubble ${msg.sender === 'USER' ? 'message-user' : 'message-ai'}`}
              >
                <div className="message-sender">{msg.sender}</div>
                <div>{msg.message}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
