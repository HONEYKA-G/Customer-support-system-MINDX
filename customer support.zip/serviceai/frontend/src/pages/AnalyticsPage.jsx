import { useEffect, useMemo, useState } from 'react';
import { fetchTickets } from '../services/api.js';

export default function AnalyticsPage() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    loadTickets();
  }, []);

  async function loadTickets() {
    setLoading(true);
    setError('');
    try {
      const data = await fetchTickets();
      setTickets(data || []);
    } catch (err) {
      setError('Unable to load analytics. Please ensure the backend is running.');
    } finally {
      setLoading(false);
    }
  }

  const counts = useMemo(() => {
    return {
      total: tickets.length,
      open: tickets.filter((item) => item.status === 'OPEN').length,
      needsHuman: tickets.filter((item) => item.status === 'NEEDS_HUMAN').length,
      resolved: tickets.filter((item) => item.status === 'RESOLVED').length,
    };
  }, [tickets]);

  return (
    <div>
      <div className="section-header">
        <div>
          <h2>Analytics</h2>
          <p>Insights from the support pipeline and recent ticket activity.</p>
        </div>
      </div>

      {error && <div className="error-box">{error}</div>}

      <div className="dashboard-summary">
        <div className="summary-card blue">
          <span>Total Tickets</span>
          <h3>{counts.total}</h3>
          <p>All ticket activity in the system.</p>
        </div>
        <div className="summary-card yellow">
          <span>Open</span>
          <h3>{counts.open}</h3>
          <p>Pending customer requests.</p>
        </div>
        <div className="summary-card red">
          <span>Needs Human</span>
          <h3>{counts.needsHuman}</h3>
          <p>Urgent escalations.</p>
        </div>
        <div className="summary-card green">
          <span>Resolved</span>
          <h3>{counts.resolved}</h3>
          <p>Closed and solved issues.</p>
        </div>
      </div>

      <div className="card analytics-card">
        <h3>Recent trends</h3>
        <p>Ticket volume grows as the system handles more customer interactions. Keep a close watch on escalations.</p>
        <div className="analytics-row">
          <div className="analytics-metric">
            <span>Fastest response time</span>
            <strong>1.2 hrs</strong>
          </div>
          <div className="analytics-metric">
            <span>Resolve rate</span>
            <strong>{counts.total ? `${Math.round((counts.resolved / counts.total) * 100)}%` : '0%'}</strong>
          </div>
          <div className="analytics-metric">
            <span>Escalation share</span>
            <strong>{counts.total ? `${Math.round((counts.needsHuman / counts.total) * 100)}%` : '0%'}</strong>
          </div>
        </div>
      </div>
    </div>
  );
}
