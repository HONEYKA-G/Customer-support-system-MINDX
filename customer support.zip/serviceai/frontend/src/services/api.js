const BASE_URL = '/api/tickets';

async function handleResponse(response) {
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(errorText || 'API request failed');
  }
  return response.json();
}

export async function createTicket(payload) {
  const response = await fetch(BASE_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return handleResponse(response);
}

export async function fetchTickets() {
  const response = await fetch(BASE_URL);
  return handleResponse(response);
}

export async function fetchTicketById(ticketId) {
  const response = await fetch(`${BASE_URL}/${ticketId}`);
  return handleResponse(response);
}

export async function updateTicketStatus(ticketId, status) {
  const response = await fetch(`${BASE_URL}/${ticketId}/status?status=${status}`, {
    method: 'PATCH',
  });
  return handleResponse(response);
}
