const AUTH_URL = '/api/auth';

async function handleResponse(response) {
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(errorText || 'Authentication request failed');
  }
  return response.json();
}

export async function login(username, password) {
  const response = await fetch(`${AUTH_URL}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
  return handleResponse(response);
}

export function getStoredAuthToken() {
  return localStorage.getItem('mindxToken');
}

export function saveAuthToken(token) {
  localStorage.setItem('mindxToken', token);
}

export function clearAuthToken() {
  localStorage.removeItem('mindxToken');
}
