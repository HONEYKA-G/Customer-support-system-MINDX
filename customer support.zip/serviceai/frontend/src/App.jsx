import { useEffect, useState } from 'react';
import ChatPage from './pages/ChatPage.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';
import AllTicketsPage from './pages/AllTickets.jsx';
import AnalyticsPage from './pages/AnalyticsPage.jsx';
import LoginPage from './pages/LoginPage.jsx';
import { login, getStoredAuthToken, clearAuthToken } from './services/auth.js';

const menuItems = [
  { key: 'chat', label: 'Customer Chat' },
  { key: 'dashboard', label: 'Admin Dashboard' },
  { key: 'tickets', label: 'All Tickets' },
  { key: 'analytics', label: 'Analytics' },
];

export default function App() {
  const [activePage, setActivePage] = useState('chat');
  const [adminToken, setAdminToken] = useState(getStoredAuthToken());
  const [authError, setAuthError] = useState('');

  useEffect(() => {
    if (!adminToken && activePage !== 'chat') {
      setActivePage('dashboard');
    }
  }, [adminToken]);

  async function handleLogin(username, password) {
    setAuthError('');
    try {
      const result = await login(username, password);
      localStorage.setItem('mindxToken', result.token);
      setAdminToken(result.token);
      setActivePage('dashboard');
    } catch (err) {
      setAuthError(err.message || 'Invalid credentials.');
    }
  }

  function handleLogout() {
    clearAuthToken();
    setAdminToken(null);
    setActivePage('chat');
  }

  const isAdminAuthenticated = Boolean(adminToken);

  function renderPage() {
    if (!isAdminAuthenticated && activePage !== 'chat') {
      return <LoginPage onLogin={handleLogin} error={authError} />;
    }

    switch (activePage) {
      case 'chat':
        return <ChatPage />;
      case 'dashboard':
        return <AdminDashboard />;
      case 'tickets':
        return <AllTicketsPage />;
      case 'analytics':
        return <AnalyticsPage />;
      default:
        return <ChatPage />;
    }
  }

  return (
    <div className="app-shell">
      <nav className="top-navbar">
        <div className="navbar-brand">
          <div className="brand-mark">M</div>
          <div>
            <strong>MindX Service AI</strong>
            <p>AI support and admin workspace.</p>
          </div>
        </div>

        <div className="navbar-menu">
          {menuItems.map((item) => (
            <button
              key={item.key}
              className={`navbar-item ${activePage === item.key ? 'active' : ''}`}
              onClick={() => setActivePage(item.key)}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="navbar-actions">
          <div className="status-pill status-open">System Online</div>
          {isAdminAuthenticated ? (
            <button className="btn-link" onClick={handleLogout}>
              Logout
            </button>
          ) : (
            <p className="login-note">Login to access admin tools.</p>
          )}
        </div>
      </nav>

      <main className="page-main">
        <div className="page-content">{renderPage()}</div>
      </main>
    </div>
  );
}
