@echo off
echo Running frontend build and backend start from the frontend folder...
cd /d %~dp0
if not exist package.json (
  echo Unable to find package.json in %CD%
  exit /b 1
)

echo Building frontend...
call npm run build
if errorlevel 1 (
  echo Frontend build failed.
  exit /b 1
)

echo Copying build output to backend static resources...
robocopy "%~dp0dist" "%~dp0..\serviceai\src\main\resources\static" /MIR
if errorlevel 8 (
  echo Robocopy failed.
  exit /b 1
)

echo Starting backend Spring Boot application...
cd /d "%~dp0..\serviceai"
if exist run.bat (
  call run.bat
  exit /b 0
) else (
  echo Backend run.bat not found in %CD%
  exit /b 1
)
