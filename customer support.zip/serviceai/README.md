# MindX Service AI

A mini Service AI system built for the MindX Full Stack Developer Intern assignment.

## Tech Stack

- Java 21
- Spring Boot 3.2
- Spring Data JPA / Hibernate
- H2 (in-memory demo database)
- React 18 + Vite
- REST APIs

## Features Implemented

- Customer support ticket creation
- AI-powered response with OpenAI fallback mock logic
- Automatic escalation for keywords like `refund`, `complaint`, `angry`, `fraud`
- Ticket list and status management for admin
- Ticket detail view with conversation history
- Structured backend exception handling
- Responsive UI with chat and admin views

## Backend Structure

- `src/main/java/com/mindx/serviceai/ServiceaiApplication.java` - Spring Boot entrypoint
- `src/main/java/com/mindx/serviceai/controller/TicketController.java` - REST API endpoints
- `src/main/java/com/mindx/serviceai/service/TicketService.java` - ticket workflow
- `src/main/java/com/mindx/serviceai/service/AiService.java` - OpenAI / mock response
- `src/main/java/com/mindx/serviceai/service/EscalationService.java` - keyword escalation logic
- `src/main/java/com/mindx/serviceai/entity` - JPA entities (`User`, `Ticket`, `Message`)
- `src/main/resources/application.properties` - H2 config + OpenAI fallback

## Frontend Structure

- `frontend/src/App.jsx` - application shell
- `frontend/src/pages/ChatPage.jsx` - customer chat UI
- `frontend/src/pages/AdminDashboard.jsx` - admin ticket management
- `frontend/src/services/api.js` - backend API client
- `frontend/src/index.css` - UI styling

## Run Locally

### Backend

```cmd
cd C:\Users\madhu\Downloads\serviceai
mvn spring-boot:run
```

The backend runs on `http://localhost:8081`.

### Frontend

```cmd
cd C:\Users\madhu\Downloads\serviceai\frontend
npm install
npm run dev
```

The frontend runs on `http://localhost:5173` with API proxy to the backend.

## Notes

- The backend uses H2 in-memory database for a working demo without external setup.
- To connect to MySQL, update `src/main/resources/application.properties` and add your database credentials.
- If you want OpenAI responses, add a valid key to `openai.api.key` in `application.properties`.
