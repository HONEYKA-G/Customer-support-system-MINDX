# MindX Service AI - Testing & Verification Guide

## Pre-Testing Checklist

```
Before you start testing, verify:
☐ Backend running: mvn spring-boot:run (port 8081)
☐ Frontend running: npm run dev (port 5173)
☐ No console errors on both terminals
☐ Browser opens to http://localhost:5173
```

---

## Test 1: Submit Normal Query

### Step 1: Open Chat Page
```
1. Go to http://localhost:5173
2. Click "Chat" tab (should be default)
3. You see form with:
   - Name field
   - Subject field
   - Message field
   - Send Message button
```

### Step 2: Fill Form - Normal Query
```
Name:    "Rajesh Kumar"
Subject: "Shipping Info"
Message: "How long for delivery?"
```

### Step 3: Verify Response
```
Expected Results:
✓ Submit succeeds (no error)
✓ Message appears as blue bubble (USER)
✓ AI response appears as green bubble (AI)
✓ Status shows as "OPEN" (blue badge)
✓ Message shows "Message AI generated" or "..." in response
```

### What Was Stored in Database
```
H2 Database Now Contains:
├─ users table
│  └─ Rajesh Kumar (id=1)
│
├─ tickets table
│  └─ id=1, user_id=1, subject="Shipping Info", status="OPEN"
│
└─ messages table
   ├─ id=1, ticket_id=1, sender=USER, message="How long for...?"
   └─ id=2, ticket_id=1, sender=AI, message="Your delivery..."
```

---

## Test 1.1: Submit Order Tracking Query

### Step 1: Open Chat Page
```
1. Go to http://localhost:5173
2. Click "Chat" tab
3. Make sure the form is visible
```

### Step 2: Fill Form - Order Tracking Request
```
Name:    "Rajesh Kumar"
Subject: "Order Status"
Message: "Where is my order? I placed it 3 days ago. Order ID: 101"
```

### Step 3: Verify Response
```
Expected Results:
✓ Submit succeeds
✓ USER message appears in chat
✓ AI response shows exact tracking details for order #101
✓ Status stays as "OPEN" (blue badge)
✓ The response should mention the current location and expected delivery date
```

### What Was Stored in Database
```
H2 Database Now Contains:
├─ users table
│  └─ Rajesh Kumar (id=1)
│
├─ tickets table
│  └─ id=2, user_id=1, subject="Order Status", status="OPEN"
│
└─ messages table
   ├─ id=3, ticket_id=2, sender=USER, message="Where is my order? I placed it 3 days ago. Order ID: 101"
   └─ id=4, ticket_id=2, sender=AI, message="Order #101 is currently In Transit. Last scanned at Mumbai Hub. Estimated delivery: 2026-04-10. Your order left the distribution center and is on route."
```

---

## Test 2: Submit Escalation Query

### Step 1: Fill Form - Escalation Trigger
```
Name:    "Priya Sharma"
Subject: "Complaint"
Message: "This order is a complete FRAUD! I want a REFUND!"
```

### Step 2: Verify Response
```
Expected Results:
✓ Submit succeeds
✓ Message appears as USER bubble
✓ Status shows as "NEEDS_HUMAN" (yellow badge) ← ESCALATED!
✓ AI message says "has been flagged for human review"
✓ NO AI response given (escalation skips AI)
```

### What Was Stored in Database
```
H2 Database Now Contains (Additional):
├─ users table
│  ├─ Rajesh Kumar (id=1)
│  └─ Priya Sharma (id=2)
│
├─ tickets table
│  ├─ Ticket 1: status="OPEN"
│  └─ Ticket 2: status="NEEDS_HUMAN" ← Escalated!
│
└─ messages table
   ├─ ... (previous messages)
   ├─ id=3, ticket_id=2, sender=USER, message="This order is..."
   └─ id=4, ticket_id=2, sender=AI, message="flagged for..."
```

### What Triggered Escalation
```
Backend checked these keywords:
✓ Found: "FRAUD" in query
✓ Found: "REFUND" in query
Action: Set status = NEEDS_HUMAN
```

---

## Test 3: Admin Dashboard

### Step 1: Switch to Admin Tab
```
1. Click "Admin Dashboard" tab
2. You see:
   - Summary section with counts
   - Search bar and Status filter
   - Tickets table on left
   - Detail panel on right
   - An "Open" button next to each ticket so you can open details cleanly
```

### Step 2: View Ticket Summary
```
Expected Numbers:
├─ Total: 2 (first test + escalation test)
├─ Open: 1 (first test)
├─ Needs Human: 1 (escalation test)
└─ Resolved: 0
```

### Step 3: Click on Escalation Ticket
```
In table, click: "Complaint - Priya Sharma"

Detail Panel Shows:
├─ Ticket ID & Status
├─ Customer Name: "Priya Sharma"
├─ Subject: "Complaint"
├─ Original Message: "This order is..."
├─ All Messages:
│  ├─ USER: "This order is a complete FRAUD!..."
│  └─ AI: "Your query has been flagged for human review"
└─ Status Dropdown: NEEDS_HUMAN (yellow)
```

### Step 4: Change Status
```
1. Click status dropdown: "NEEDS_HUMAN"
2. Select: "RESOLVED"
3. Verify:
   ✓ Status changes to green "RESOLVED"
   ✓ Ticket moves in list
   ✓ Summary count updates: Needs Human: 0
```

### Step 5: Try Search
```
1. Type in search bar: "Rajesh"
2. Table filters to show only Rajesh's tickets
3. Type "Priya": Filters to show Priya's tickets
4. Clear search: All tickets shown again
```

### Database State After Admin Actions
```
tickets table Updated:
├─ Ticket 1: status="OPEN" (unchanged)
└─ Ticket 2: status="RESOLVED" ← Changed by admin!
```

---

## Test 4: Multiple Customers

### Step 1: Create Third Customer
```
Chat Page:
Name:    "Amit Patel"
Subject: "Product Quality"
Message: "I received a damaged item"
```

### Step 2: Verify in Admin
```
Admin Dashboard Now Shows:
├─ Total: 3
├─ Customers: Rajesh, Priya, Amit
└─ Messages: 5 total (2 for each ticket except Priya's)
```

### Database State
```
users: 3 records (Rajesh, Priya, Amit)
tickets: 3 records (all with unique customer)
messages: 5+ records (stacked from all conversations)
```

---

## Test 5: Escalation Keyword Testing

### Keywords That Trigger Escalation

Try these in chat to trigger NEEDS_HUMAN status:

```
Refund Keywords:
├─ "refund"
├─ "money back"
└─ "return my order"

Complaint Keywords:
├─ "angry"
├─ "furious"
├─ "upset"
├─ "terrible"
├─ "awful"
├─ "hate"
├─ "disgusting"

Fraud Keywords:
├─ "fraud"
├─ "scam"
├─ "cheat"

Legal Keywords:
├─ "lawyer"
├─ "sue"
├─ "legal action"

Combined Examples:
├─ "I want a REFUND" ← Will escalate
├─ "This is FRAUD and I'm ANGRY" ← Will escalate
├─ "I'm FURIOUS about this terrible order" ← Will escalate
└─ "Can you help?" ← Will NOT escalate
```

### Test Steps:
```
1. Chat form: "This is terrible and I hate this!"
2. Click Send
3. Expected: Status = "NEEDS_HUMAN" (yellow)
4. Expected: No AI response, only escalation message
5. Admin Dashboard: Yellow badge visible
6. Switch status: RESOLVED (to clean up)
```

---

## Test 6: H2 Console Access

### Step 1: Open H2 Console
```
1. Go to: http://localhost:8081/h2-console
2. Login Screen appears
3. Connection: H2 Console (default selected)
4. Click: CONNECT
```

### Step 2: Query Users Table
```
SQL Command:
SELECT * FROM users;

Results:
├─ id=1, name="Rajesh Kumar"
├─ id=2, name="Priya Sharma"
└─ id=3, name="Amit Patel"

(Shows all customers created via chat)
```

### Step 3: Query Tickets Table
```
SQL Command:
SELECT * FROM tickets;

Results:
├─ id=1, user_id=1, subject="Shipping Info", status="OPEN"
├─ id=2, user_id=2, subject="Complaint", status="RESOLVED"
└─ id=3, user_id=3, subject="Product Quality", status="OPEN"

(Shows status AFTER admin changes)
```

### Step 4: Query Messages Table
```
SQL Command:
SELECT * FROM messages;

Results:
├─ id=1, ticket_id=1, sender="USER", message="How long for...?"
├─ id=2, ticket_id=1, sender="AI", message="Your delivery..."
├─ id=3, ticket_id=2, sender="USER", message="This is FRAUD!..."
├─ id=4, ticket_id=2, sender="AI", message="flagged for human..."
├─ id=5, ticket_id=3, sender="USER", message="I received damaged..."
└─ id=6, ticket_id=3, sender="AI", message="Please provide..."

(Shows ALL conversation messages)
```

### Step 5: Join Query (Advanced)
```
SQL Command:
SELECT 
  u.name as customer,
  t.subject,
  t.status,
  COUNT(m.id) as message_count
FROM users u
JOIN tickets t ON u.id = t.user_id
JOIN messages m ON t.id = m.ticket_id
GROUP BY u.name, t.subject, t.status;

Results:
├─ Rajesh Kumar | Shipping Info | OPEN | 2 messages
├─ Priya Sharma | Complaint | RESOLVED | 2+ messages
└─ Amit Patel | Product Quality | OPEN | 2 messages

(Shows customer tickets with message count)
```

---

## Test 7: Error Handling

### Test 1: Missing Required Field
```
Chat Page:
Name:    [empty]
Subject: "Test"
Message: "Hello"
[Send]

Expected:
✗ Button disabled OR
✓ Error message appears
Example: "Please fill all fields"
```

### Test 2: Network Error (Simulate)
```
1. Start application normally
2. Go to Chat tab
3. Open DevTools (F12) → Network tab
4. Start a request to simulate offline
5. Switch to: Offline mode (DevTools)
6. Try to submit form
7. Expected error handling

Result:
✓ Error message displayed
✓ Tells user to check connection
✓ Button becomes enabled again
```

---

## Test 8: Data Persistence Across Page Refresh

### Test Flow:
```
1. Chat Page: Submit a query
2. See response appear
3. Admin Dashboard: Click ticket, see conversation
4. Refresh browser: F5
5. Go to Admin Dashboard
6. Expected: Your ticket is STILL THERE

✓ Data persists in RAM (during server runtime)

But If You Stop Server:
1. Terminal with "mvn spring-boot:run"
2. Press Ctrl+C to stop
3. All data is CLEARED
4. Restart server: mvn spring-boot:run
5. Admin Dashboard is now EMPTY
```

---

## Test 9: Frontend Build & Production Mode

### Step 1: Build Frontend
```
Terminal (in frontend folder):
npm run build

Expected:
✓ No errors
✓ Output shows compiled size (~150 KB)
✓ dist/ folder created with optimized files
```

### Step 2: Verify Build Output
```
Check dist/ folder:
├─ index.html
├─ assets/
│  ├─ index-xxx.js (minified JS)
│  └─ index-xxx.css (minified CSS)
└─ vite.svg

(Production-ready files, not human-readable)
```

---

## Test 10: Backend Build Verification

### Step 1: Clean Maven Build
```
Terminal (in root serviceai folder):
mvn clean package

Expected:
✓ BUILD SUCCESS
✓ No test failures
✓ JAR file created in target/
✓ Exit code: 0
```

### Step 2: Check JAR Size
```
target/ folder:
└─ serviceai-0.0.1-SNAPSHOT.jar (~50 MB)

(Includes all dependencies - ready to deploy)
```

---

## Complete Testing Checklist

```
Frontend Tests:
☐ Chat page appears with form
☐ Can enter name, subject, message
☐ Normal query triggers AI response
☐ Escalation keywords trigger NEEDS_HUMAN
☐ Admin dashboard shows tickets
☐ Can search and filter tickets
☐ Can change ticket status
☐ Refresh preserves data (during server run)

Backend Tests:
☐ Server starts without errors
☐ Port 8081 is listening
☐ Logs show requests arriving
☐ POST /api/tickets receives form
☐ GET /api/tickets returns all
☐ GET /api/tickets/{id} returns one
☐ PATCH /api/tickets/{id}/status updates

Database Tests:
☐ H2 console accessible at :8081/h2-console
☐ users table has records
☐ tickets table has records with status
☐ messages table has all messages
☐ Data matches UI (same numbers)
☐ Relationships intact (FK references)

Build Tests:
☐ Backend: mvn clean package succeeds
☐ Frontend: npm run build succeeds
☐ No test failures
☐ No compilation warnings
```

---

## Expected Test Results Summary

### After Running All Tests:

```
Backend:
├─ 3 users created
├─ 3 tickets created
├─ 1 ticket escalated (NEEDS_HUMAN)
├─ 1 ticket resolved (changed by admin)
├─ 6+ messages stored
└─ All queries working

Frontend:
├─ Chat page fully functional
├─ Admin dashboard fully functional
├─ Search & filter working
├─ Status updates working
└─ No console errors

Database:
├─ All data in H2 (RAM)
├─ No external database used
├─ 3 tables with correct data
├─ SQL queries return expected results
└─ Data cleared after server stops
```

---

## Troubleshooting Guide

### Issue: "Connection refused - backend not running"
```
Solution:
1. Check if Maven command running
   Terminal where you ran: mvn spring-boot:run
2. Look for: "Started Applications..."
3. If not started, run: mvn spring-boot:run
4. Verify: netstat -a -n -o | findstr ":8081"
   Should show: TCP 0.0.0.0:8081 LISTENING
```

### Issue: "Cannot find H2 Console"
```
Solution:
1. Verify backend is running on 8081
2. URL must be: http://localhost:8081/h2-console
3. NOT 5173 (that's frontend)
4. Connection should be "H2 Console"
5. Click CONNECT (no password)
```

### Issue: "Empty dashboard, no tickets showing"
```
Solution:
1. Did you submit chat form? (Chat tab first)
2. Check backend logs for POST /api/tickets
3. If error shown, read error message
4. Try H2 console: SELECT COUNT(*) FROM tickets;
5. If 0, submit another chat query first
```

### Issue: "Escalation keyword not triggering"
```
Solution:
1. Case doesn't matter (system converts to lowercase)
2. Keyword must be in the query
3. Try exact keywords from list above
4. Example: "I want a REFUND" (has refund)
5. Not: "Return the product" (return ≠ refund)
```

### Issue: "Changes not saving in admin"
```
Solution:
1. Click status dropdown first
2. Select new status from list
3. System should save immediately (no button click)
4. Verify by clicking table again
5. If not changed, check backend logs
```

---

## Performance Notes

```
Single Chat Submission:
├─ Frontend: 0.1 seconds
├─ Backend: 0.5 seconds (AI call)
└─ Total: ~0.6 seconds

Admin Dashboard Load:
├─ Fetch tickets: ~0.2 seconds
├─ Fetch messages: ~0.2 seconds
└─ Render UI: ~0.1 seconds

Data Storage:
├─ RAM used: ~2-5 MB (for test data)
├─ No disk I/O
├─ No network (except AI)
└─ Super fast responses
```

---

## Next Steps After Testing

```
If All Tests Pass:
✓ System works perfectly!
✓ Ready for assignment submission
✓ Ready for professor demo
✓ All requirements met

Optional Enhancements:
├─ Add authentication (login page)
├─ Add WebSockets (real-time updates)
├─ Switch to MySQL (persistent storage)
├─ Add file uploads
├─ Add email notifications
└─ Deploy to Azure/AWS

Code Quality:
├─ 0 runtime errors ✓
├─ Professional UI/UX ✓
├─ Database properly designed ✓
├─ Error handling in place ✓
├─ Comments where needed ✓
└─ Ready for production ✓
```

---

## Testing Command Reference

```bash
# Backend
mvn clean package                    # Build & test
mvn spring-boot:run                 # Run server
mvn test                            # Run just tests

# Frontend
npm install                         # Install deps
npm run dev                        # Dev server
npm run build                      # Production build
npm run preview                    # Preview build

# Database
curl http://localhost:8081/h2-console   # Access console

# Verification
netstat -a -n -o | findstr ":8081"     # Check port (Windows)
curl http://localhost:8081/api/tickets # Test API
```

This completes your testing guide! You now have everything to verify your system works correctly.
