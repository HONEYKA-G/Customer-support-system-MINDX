package com.mindx.serviceai.controller;

import com.mindx.serviceai.dto.LoginRequest;
import com.mindx.serviceai.dto.LoginResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        if (request == null || request.getUsername() == null || request.getPassword() == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Username and password are required.");
        }

        if ("Mindx@admin".equals(request.getUsername()) && "123456".equals(request.getPassword())) {
            return ResponseEntity.ok(new LoginResponse("mindx-admin-token-2026", "ADMIN"));
        }

        throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Invalid admin credentials.");
    }
}
