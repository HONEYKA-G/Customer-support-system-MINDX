package com.mindx.serviceai.entity;

public enum TicketStatus {
    OPEN, RESOLVED, NEEDS_HUMAN
}