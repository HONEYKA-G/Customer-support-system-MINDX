package com.mindx.serviceai.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "tickets")
public class Ticket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long userId;
    private String subject;
    private String orderId;

    @Column(columnDefinition = "TEXT")
    private String query;

    @Enumerated(EnumType.STRING)
    private TicketStatus status;
    private LocalDateTime createdAt;

    @PrePersist
    public void prePersist() {
        this.createdAt = LocalDateTime.now();
        if (this.status == null) this.status = TicketStatus.OPEN;
    }

    public Long getId() { return id; }
    public Long getUserId() { return userId; }
    public String getSubject() { return subject; }
    public String getOrderId() { return orderId; }
    public String getQuery() { return query; }
    public TicketStatus getStatus() { return status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setId(Long id) { this.id = id; }
    public void setUserId(Long userId) { this.userId = userId; }
    public void setSubject(String subject) { this.subject = subject; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public void setQuery(String query) { this.query = query; }
    public void setStatus(TicketStatus status) { this.status = status; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public static TicketBuilder builder() { return new TicketBuilder(); }
    public static class TicketBuilder {
        private Long userId;
        private String subject;
        private String orderId;
        private String query;
        private TicketStatus status;
        public TicketBuilder userId(Long userId) { this.userId = userId; return this; }
        public TicketBuilder subject(String subject) { this.subject = subject; return this; }
        public TicketBuilder orderId(String orderId) { this.orderId = orderId; return this; }
        public TicketBuilder query(String query) { this.query = query; return this; }
        public TicketBuilder status(TicketStatus status) { this.status = status; return this; }
        public Ticket build() {
            Ticket t = new Ticket();
            t.userId = this.userId;
            t.subject = this.subject;
            t.orderId = this.orderId;
            t.query = this.query;
            t.status = this.status;
            return t;
        }
    }
}