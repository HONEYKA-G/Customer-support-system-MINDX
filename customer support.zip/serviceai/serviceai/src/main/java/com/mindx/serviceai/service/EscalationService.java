package com.mindx.serviceai.service;

import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Determines whether a customer query should be automatically escalated
 * to a human agent.  Extracted into its own service so the logic stays
 * testable and easy to extend without touching TicketService.
 */
@Service
public class EscalationService {

    private static final List<String> ESCALATION_KEYWORDS = List.of(
            "refund", "complaint", "angry", "furious", "scam", "fraud",
            "cheat", "legal", "sue", "lawyer", "terrible", "awful",
            "hate", "disgusting", "unacceptable", "horrible", "worst"
    );

    /**
     * Returns true when the query contains at least one escalation keyword.
     */
    public boolean requiresHumanEscalation(String query) {
        if (query == null || query.isBlank()) return false;
        String lower = query.toLowerCase();
        return ESCALATION_KEYWORDS.stream().anyMatch(lower::contains);
    }
}