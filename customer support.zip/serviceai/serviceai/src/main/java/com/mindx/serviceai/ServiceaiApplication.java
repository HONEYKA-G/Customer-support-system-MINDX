package com.mindx.serviceai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

@SpringBootApplication
public class ServiceaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceaiApplication.class, args);
	}

	@EventListener(ApplicationReadyEvent.class)
	public void showStartupMessage() {
		System.out.println("\n");
		System.out.println("═══════════════════════════════════════════════════════════════════════════════════");
		System.out.println("                    ✅ APPLICATION STARTED SUCCESSFULLY");
		System.out.println("═══════════════════════════════════════════════════════════════════════════════════");
		System.out.println("");
		System.out.println("  🔗 ACCESS THE APPLICATION HERE:");
		System.out.println("");
		System.out.println("     ➞ http://localhost:8080");
		System.out.println("");
		System.out.println("═══════════════════════════════════════════════════════════════════════════════════");
		System.out.println("");
		System.out.println("  📖 HOW TO USE:");
		System.out.println("");
		System.out.println("     1. Open your browser and go to: http://localhost:8080");
		System.out.println("     2. Enter an Order ID (e.g., 101, 102, 103)");
		System.out.println("     3. Ask a question: 'Where is my order?'");
		System.out.println("     4. The AI will respond with order tracking details");
		System.out.println("");
		System.out.println("═══════════════════════════════════════════════════════════════════════════════════");
		System.out.println("");
		System.out.println("  🏥 ADMIN DASHBOARD:");
		System.out.println("");
		System.out.println("     ➞ http://localhost:8080/admin");
		System.out.println("");
		System.out.println("  💾 DATABASE CONSOLE:");
		System.out.println("");
		System.out.println("     ➞ http://localhost:8080/h2-console");
		System.out.println("");
		System.out.println("═══════════════════════════════════════════════════════════════════════════════════");
		System.out.println("");
		System.out.println("  📌 SAMPLE ORDERS TO TRY:");
		System.out.println("");
		System.out.println("     • Order 101 → In Transit");
		System.out.println("     • Order 102 → Delivered");
		System.out.println("     • Order 103 → Escalated Support");
		System.out.println("");
		System.out.println("═══════════════════════════════════════════════════════════════════════════════════");
		System.out.println("");
		System.out.println("  ⏹️  TO STOP THE SERVER: Press Ctrl+C in this terminal");
		System.out.println("");
		System.out.println("═══════════════════════════════════════════════════════════════════════════════════\n");
	}

}
