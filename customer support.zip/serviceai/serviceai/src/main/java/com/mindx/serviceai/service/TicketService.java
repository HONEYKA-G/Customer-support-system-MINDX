package com.mindx.serviceai.service;

import com.mindx.serviceai.dto.CreateTicketRequest;
import com.mindx.serviceai.dto.MessageResponse;
import com.mindx.serviceai.dto.TicketResponse;
import com.mindx.serviceai.entity.Message;
import com.mindx.serviceai.entity.SenderType;
import com.mindx.serviceai.entity.Ticket;
import com.mindx.serviceai.entity.TicketStatus;
import com.mindx.serviceai.entity.User;
import com.mindx.serviceai.repository.MessageRepository;
import com.mindx.serviceai.repository.TicketRepository;
import com.mindx.serviceai.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TicketService {

    private final TicketRepository ticketRepository;
    private final MessageRepository messageRepository;
    private final UserRepository userRepository;
    private final AiService aiService;
    private final EscalationService escalationService;
    private final OrderTrackingService orderTrackingService;

    public TicketService(TicketRepository ticketRepository,
                         MessageRepository messageRepository,
                         UserRepository userRepository,
                         AiService aiService,
                         EscalationService escalationService,
                         OrderTrackingService orderTrackingService) {
        this.ticketRepository = ticketRepository;
        this.messageRepository = messageRepository;
        this.userRepository = userRepository;
        this.aiService = aiService;
        this.escalationService = escalationService;
        this.orderTrackingService = orderTrackingService;
    }

    // -----------------------------------------------------------------------
    // Create ticket  — full Day 2 flow
    // -----------------------------------------------------------------------

    @Transactional
    public TicketResponse createTicket(CreateTicketRequest request) {
        if (request.getQuery() == null || request.getQuery().isBlank()) {
            throw new IllegalArgumentException("Query must not be empty.");
        }

        Long userId = resolveUserId(request.getName());
        boolean escalate = escalationService.requiresHumanEscalation(request.getQuery());
        String trackingInfo = orderTrackingService.getTrackingMessage(request.getQuery(), request.getOrderId()).orElse(null);
        TicketStatus initialStatus = escalate ? TicketStatus.NEEDS_HUMAN : TicketStatus.OPEN;

        Ticket ticket = Ticket.builder()
                .userId(userId)
                .subject(request.getSubject())
                .orderId(request.getOrderId())
                .query(request.getQuery())
                .status(initialStatus)
                .build();
        ticket = ticketRepository.save(ticket);

        Message userMsg = Message.builder()
                .ticketId(ticket.getId())
                .sender(SenderType.USER)
                .message(request.getQuery())
                .build();
        messageRepository.save(userMsg);

        String aiText;
        if (escalate) {
            aiText = "Your query has been flagged for review by our support team. " +
                    "A human agent will get back to you shortly.";
        } else if (trackingInfo != null) {
            aiText = trackingInfo;
        } else {
            aiText = aiService.getAiResponse(request.getQuery(), request.getOrderId());
        }

        Message aiMsg = Message.builder()
                .ticketId(ticket.getId())
                .sender(SenderType.AI)
                .message(aiText)
                .build();
        messageRepository.save(aiMsg);

        List<Message> allMessages = List.of(userMsg, aiMsg);
        return mapToResponse(ticket, allMessages, aiText, request.getName(), trackingInfo);
    }

    public List<TicketResponse> getAllTickets() {
        return ticketRepository.findAllByOrderByCreatedAtDesc().stream()
                .map(ticket -> {
                    List<Message> messages = messageRepository
                            .findByTicketIdOrderByTimestampAsc(ticket.getId());
                    String trackingInfo = orderTrackingService.getTrackingMessage(ticket.getQuery(), ticket.getOrderId()).orElse(null);
                    return mapToResponse(ticket, messages, null, findUserName(ticket.getUserId()), trackingInfo);
                })
                .collect(Collectors.toList());
    }

    public TicketResponse getTicketById(Long id) {
        Ticket ticket = findTicketOrThrow(id);
        List<Message> messages = messageRepository.findByTicketIdOrderByTimestampAsc(id);
        String trackingInfo = orderTrackingService.getTrackingMessage(ticket.getQuery(), ticket.getOrderId()).orElse(null);
        return mapToResponse(ticket, messages, null, findUserName(ticket.getUserId()), trackingInfo);
    }

    @Transactional
    public TicketResponse updateStatus(Long id, String status) {
        Ticket ticket = findTicketOrThrow(id);
        try {
            ticket.setStatus(TicketStatus.valueOf(status.toUpperCase()));
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Invalid status value: " + status +
                    ". Allowed: OPEN, RESOLVED, NEEDS_HUMAN");
        }
        ticketRepository.save(ticket);
        List<Message> messages = messageRepository.findByTicketIdOrderByTimestampAsc(id);
        return mapToResponse(ticket, messages, null, findUserName(ticket.getUserId()), null);
    }

    private Long resolveUserId(String name) {
        if (name == null || name.isBlank()) {
            return null;
        }
        Optional<User> existing = userRepository.findByName(name.trim());
        if (existing.isPresent()) {
            return existing.get().getId();
        }
        User user = new User();
        user.setName(name.trim());
        return userRepository.save(user).getId();
    }

    private String findUserName(Long userId) {
        if (userId == null) return "Guest";
        return userRepository.findById(userId)
                .map(User::getName)
                .orElse("Guest");
    }

    private Ticket findTicketOrThrow(Long id) {
        return ticketRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Ticket not found: " + id));
    }

    private TicketResponse mapToResponse(Ticket ticket,
                                         List<Message> messages,
                                         String aiResponse,
                                         String customerName,
                                         String trackingInfo) {
        return TicketResponse.builder()
                .id(ticket.getId())
                .userId(ticket.getUserId())
                .customerName(customerName)
                .subject(ticket.getSubject())
                .orderId(ticket.getOrderId())
                .query(ticket.getQuery())
                .status(ticket.getStatus())
                .createdAt(ticket.getCreatedAt())
                .aiResponse(aiResponse)
                .trackingInfo(trackingInfo)
                .messages(messages.stream().map(m -> MessageResponse.builder()
                        .id(m.getId())
                        .sender(m.getSender())
                        .message(m.getMessage())
                        .timestamp(m.getTimestamp())
                        .build()).collect(Collectors.toList()))
                .build();
    }
}
