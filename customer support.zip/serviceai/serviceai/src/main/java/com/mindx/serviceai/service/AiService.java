package com.mindx.serviceai.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Calls OpenAI's chat completion endpoint.
 * Falls back to a deterministic mock response if the API key is absent or the
 * call fails – so the app stays fully runnable without an OpenAI account.
 */
@Service
public class AiService {

    private static final Logger log = LoggerFactory.getLogger(AiService.class);

    @Value("${openai.api.key:}")
    private String apiKey;

    @Value("${openai.api.url:https://api.openai.com/v1/chat/completions}")
    private String apiUrl;

    @Value("${openai.model:gpt-3.5-turbo}")
    private String model;

    private final RestTemplate restTemplate = new RestTemplate();
    private final OrderTrackingService orderTrackingService;

    public AiService(OrderTrackingService orderTrackingService) {
        this.orderTrackingService = orderTrackingService;
    }

    private static final String SYSTEM_PROMPT =
            "You are a helpful customer support agent for MindX Digital Softwares. " +
            "Respond concisely and professionally. If you cannot resolve the issue, " +
            "ask for more details or suggest escalation to a human agent.";

    public String getAiResponse(String userMessage, String orderId) {
        // First, check if it's a tracking-related query and we have order info
        Optional<String> trackingResponse = orderTrackingService.getTrackingMessage(userMessage, orderId);
        if (trackingResponse.isPresent()) {
            return trackingResponse.get();
        }

        if (apiKey == null || apiKey.isBlank() || apiKey.equals("YOUR_OPENAI_KEY")) {
            log.warn("OpenAI API key not configured – using mock response.");
            return mockResponse(userMessage, orderId);
        }
        try {
            return callOpenAi(userMessage, orderId);
        } catch (Exception e) {
            log.error("OpenAI call failed, falling back to mock: {}", e.getMessage());
            return mockResponse(userMessage, orderId);
        }
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    private String callOpenAi(String userMessage, String orderId) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(apiKey);

        String enhancedPrompt = SYSTEM_PROMPT;
        if (orderId != null && !orderId.isBlank()) {
            enhancedPrompt += " The user is inquiring about order ID: " + orderId + ". If this is a tracking or order status query, provide accurate information.";
        }

        Map<String, Object> body = Map.of(
                "model", model,
                "messages", List.of(
                        Map.of("role", "system", "content", enhancedPrompt),
                        Map.of("role", "user",   "content", userMessage)
                ),
                "max_tokens", 300,
                "temperature", 0.7
        );

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);
        ResponseEntity<Map> response = restTemplate.postForEntity(apiUrl, entity, Map.class);

        @SuppressWarnings("unchecked")
        List<Map<String, Object>> choices =
                (List<Map<String, Object>>) response.getBody().get("choices");
        @SuppressWarnings("unchecked")
        Map<String, Object> message =
                (Map<String, Object>) choices.get(0).get("message");

        return (String) message.get("content");
    }

    /**
     * Keyword-based mock so the app is demo-able without any API key.
     */
    private String mockResponse(String query, String orderId) {
        // First, check for tracking response
        Optional<String> tracking = orderTrackingService.getTrackingMessage(query, orderId);
        if (tracking.isPresent()) {
            return tracking.get();
        }

        String lower = query.toLowerCase();

        if (lower.contains("refund") || lower.contains("money")) {
            return "I understand your concern about the refund. Our refunds are typically " +
                   "processed within 5-7 business days. I'm escalating this to our billing " +
                   "team for urgent review.";
        }
        if (lower.contains("password") || lower.contains("login") || lower.contains("account")) {
            return "For account or login issues, please visit our password reset page at " +
                   "mindx.com/reset-password or reply with your registered email so I can " +
                   "send a reset link.";
        }
        if (lower.contains("cancel")) {
            return "To cancel an order or subscription, please provide your order/account ID. " +
                   "Cancellations within 24 hours of purchase are fully refundable.";
        }
        if (lower.contains("hello") || lower.contains("hi") || lower.contains("hey")) {
            return "Hello! Welcome to MindX Support. How can I assist you today?";
        }
        return "Thank you for reaching out to MindX Support. I've received your query and " +
               "will do my best to help. Could you please provide more details so I can " +
               "assist you better?";
    }
}