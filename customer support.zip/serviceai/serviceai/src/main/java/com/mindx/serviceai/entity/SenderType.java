package com.mindx.serviceai.entity;

public enum SenderType {
    USER, AI, ADMIN
}