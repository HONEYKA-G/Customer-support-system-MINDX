package com.mindx.serviceai.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "messages")
public class Message {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long ticketId;

    @Enumerated(EnumType.STRING)
    private SenderType sender;

    @Column(columnDefinition = "TEXT")
    private String message;
    private LocalDateTime timestamp;

    @PrePersist
    public void prePersist() {
        this.timestamp = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public Long getTicketId() { return ticketId; }
    public SenderType getSender() { return sender; }
    public String getMessage() { return message; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setId(Long id) { this.id = id; }
    public void setTicketId(Long ticketId) { this.ticketId = ticketId; }
    public void setSender(SenderType sender) { this.sender = sender; }
    public void setMessage(String message) { this.message = message; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public static MessageBuilder builder() { return new MessageBuilder(); }
    public static class MessageBuilder {
        private Long ticketId;
        private SenderType sender;
        private String message;
        public MessageBuilder ticketId(Long ticketId) { this.ticketId = ticketId; return this; }
        public MessageBuilder sender(SenderType sender) { this.sender = sender; return this; }
        public MessageBuilder message(String message) { this.message = message; return this; }
        public Message build() {
            Message m = new Message();
            m.ticketId = this.ticketId;
            m.sender = this.sender;
            m.message = this.message;
            return m;
        }
    }
}