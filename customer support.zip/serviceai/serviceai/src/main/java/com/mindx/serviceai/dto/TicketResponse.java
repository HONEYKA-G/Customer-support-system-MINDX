package com.mindx.serviceai.dto;

import com.mindx.serviceai.entity.TicketStatus;
import java.time.LocalDateTime;
import java.util.List;

public class TicketResponse {
    private Long id;
    private Long userId;
    private String customerName;
    private String subject;
    private String orderId;
    private String query;
    private TicketStatus status;
    private LocalDateTime createdAt;
    private List<MessageResponse> messages;
    private String aiResponse;
    private String trackingInfo;

    public Long getId() { return id; }
    public Long getUserId() { return userId; }
    public String getCustomerName() { return customerName; }
    public String getSubject() { return subject; }
    public String getOrderId() { return orderId; }
    public String getQuery() { return query; }
    public TicketStatus getStatus() { return status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public List<MessageResponse> getMessages() { return messages; }
    public String getAiResponse() { return aiResponse; }
    public String getTrackingInfo() { return trackingInfo; }
    public void setId(Long id) { this.id = id; }
    public void setUserId(Long userId) { this.userId = userId; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }
    public void setSubject(String subject) { this.subject = subject; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public void setQuery(String query) { this.query = query; }
    public void setStatus(TicketStatus status) { this.status = status; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public void setMessages(List<MessageResponse> messages) { this.messages = messages; }
    public void setAiResponse(String aiResponse) { this.aiResponse = aiResponse; }
    public void setTrackingInfo(String trackingInfo) { this.trackingInfo = trackingInfo; }

    public static TicketResponseBuilder builder() { return new TicketResponseBuilder(); }
    public static class TicketResponseBuilder {
        private Long id;
        private Long userId;
        private String customerName;
        private String subject;
        private String orderId;
        private String query;
        private TicketStatus status;
        private LocalDateTime createdAt;
        private List<MessageResponse> messages;
        private String aiResponse;
        private String trackingInfo;
        public TicketResponseBuilder id(Long id) { this.id = id; return this; }
        public TicketResponseBuilder userId(Long userId) { this.userId = userId; return this; }
        public TicketResponseBuilder customerName(String customerName) { this.customerName = customerName; return this; }
        public TicketResponseBuilder subject(String subject) { this.subject = subject; return this; }
        public TicketResponseBuilder orderId(String orderId) { this.orderId = orderId; return this; }
        public TicketResponseBuilder query(String query) { this.query = query; return this; }
        public TicketResponseBuilder status(TicketStatus status) { this.status = status; return this; }
        public TicketResponseBuilder createdAt(LocalDateTime createdAt) { this.createdAt = createdAt; return this; }
        public TicketResponseBuilder messages(List<MessageResponse> messages) { this.messages = messages; return this; }
        public TicketResponseBuilder aiResponse(String aiResponse) { this.aiResponse = aiResponse; return this; }
        public TicketResponseBuilder trackingInfo(String trackingInfo) { this.trackingInfo = trackingInfo; return this; }
        public TicketResponse build() {
            TicketResponse r = new TicketResponse();
            r.id = this.id;
            r.userId = this.userId;
            r.customerName = this.customerName;
            r.subject = this.subject;
            r.orderId = this.orderId;
            r.query = this.query;
            r.status = this.status;
            r.createdAt = this.createdAt;
            r.messages = this.messages;
            r.aiResponse = this.aiResponse;
            r.trackingInfo = this.trackingInfo;
            return r;
        }
    }
} 