package com.mindx.serviceai.dto;

import com.mindx.serviceai.entity.SenderType;
import java.time.LocalDateTime;

public class MessageResponse {
    private Long id;
    private SenderType sender;
    private String message;
    private LocalDateTime timestamp;

    public Long getId() { return id; }
    public SenderType getSender() { return sender; }
    public String getMessage() { return message; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setId(Long id) { this.id = id; }
    public void setSender(SenderType sender) { this.sender = sender; }
    public void setMessage(String message) { this.message = message; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public static MessageResponseBuilder builder() { return new MessageResponseBuilder(); }
    public static class MessageResponseBuilder {
        private Long id;
        private SenderType sender;
        private String message;
        private LocalDateTime timestamp;
        public MessageResponseBuilder id(Long id) { this.id = id; return this; }
        public MessageResponseBuilder sender(SenderType sender) { this.sender = sender; return this; }
        public MessageResponseBuilder message(String message) { this.message = message; return this; }
        public MessageResponseBuilder timestamp(LocalDateTime timestamp) { this.timestamp = timestamp; return this; }
        public MessageResponse build() {
            MessageResponse r = new MessageResponse();
            r.id = this.id;
            r.sender = this.sender;
            r.message = this.message;
            r.timestamp = this.timestamp;
            return r;
        }
    }
}