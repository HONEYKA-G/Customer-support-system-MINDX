package com.mindx.serviceai.service;

import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class OrderTrackingService {

    private static final Pattern ORDER_ID_PATTERN = Pattern.compile("\\b(\\d{2,6})\\b");
    private final Map<String, TrackingInfo> trackingData = new HashMap<>();

    public OrderTrackingService() {
        trackingData.put("101", new TrackingInfo("101", "In Transit", "Mumbai Hub", LocalDate.of(2026, 4, 14), "Your order left the distribution center and is on route."));
        trackingData.put("202", new TrackingInfo("202", "Delivered", "Bengaluru Delivery Center", LocalDate.of(2026, 4, 12), "Your package was delivered successfully and signed for.") );
        trackingData.put("303", new TrackingInfo("303", "Out for Delivery", "Delhi Local Facility", LocalDate.of(2026, 4, 13), "Your order is out for delivery and should arrive today.") );
        trackingData.put("404", new TrackingInfo("404", "Processing", "Pune Warehouse", LocalDate.of(2026, 4, 16), "Your order is being packed and will ship within 24 hours.") );
        trackingData.put("505", new TrackingInfo("505", "Shipped", "Chennai Hub", LocalDate.of(2026, 4, 15), "Your order has been shipped and is in transit.") );
        trackingData.put("606", new TrackingInfo("606", "Delivered", "Kolkata Delivery Center", LocalDate.of(2026, 4, 11), "Your package was delivered 2 days ago.") );
        trackingData.put("707", new TrackingInfo("707", "In Transit", "Hyderabad Hub", LocalDate.of(2026, 4, 14), "Your order is moving through the delivery network.") );
        trackingData.put("808", new TrackingInfo("808", "Out for Delivery", "Jaipur Local Facility", LocalDate.of(2026, 4, 13), "Your order will be delivered by end of today.") );
        trackingData.put("5678", new TrackingInfo("5678", "In Transit", "Ahmedabad Hub", LocalDate.of(2026, 4, 15), "Your package is moving to your area.") );
    }

    public Optional<String> getTrackingMessage(String query, String orderId) {
        String candidateId = orderId != null && !orderId.isBlank() ? orderId.trim() : extractOrderIdFromQuery(query);
        if (candidateId != null) {
            if (trackingData.containsKey(candidateId)) {
                return Optional.of(buildMessage(trackingData.get(candidateId)));
            }
            return Optional.of("I could not find order #" + candidateId + ". Please verify the Order ID and try again.");
        }

        String lower = query == null ? "" : query.toLowerCase();
        boolean isTrackingRequest = lower.contains("order") || lower.contains("tracking") || lower.contains("status") || lower.contains("delivery") || lower.contains("where") || lower.contains("ship") || lower.contains("package") || lower.contains("arrive");
        if (!isTrackingRequest) {
            return Optional.empty();
        }

        return Optional.of("I can help check your order status. Please share your order ID or order number so I can provide the exact tracking details.");
    }

    private String extractOrderIdFromQuery(String query) {
        if (query == null) {
            return null;
        }
        Matcher matcher = ORDER_ID_PATTERN.matcher(query);
        while (matcher.find()) {
            String orderId = matcher.group(1);
            if (trackingData.containsKey(orderId)) {
                return orderId;
            }
        }
        return null;
    }

    private String buildMessage(TrackingInfo info) {
        return String.format(
                "Order #%s is currently %s. Last scanned at %s. Estimated delivery: %s. %s",
                info.orderId(),
                info.status(),
                info.location(),
                info.estimatedDelivery().toString(),
                info.description()
        );
    }

    private record TrackingInfo(String orderId, String status, String location, LocalDate estimatedDelivery, String description) {
    }
}
