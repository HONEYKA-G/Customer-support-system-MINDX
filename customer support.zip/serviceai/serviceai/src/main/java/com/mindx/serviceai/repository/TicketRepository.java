package com.mindx.serviceai.repository;

import com.mindx.serviceai.entity.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TicketRepository extends JpaRepository<Ticket, Long> {
    /** Returns all tickets ordered newest-first for the admin dashboard. */
    List<Ticket> findAllByOrderByCreatedAtDesc();
}