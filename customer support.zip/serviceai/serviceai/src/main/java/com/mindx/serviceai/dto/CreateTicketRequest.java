package com.mindx.serviceai.dto;

public class CreateTicketRequest {
    private String name;
    private String subject;
    private String query;
    private String orderId;

    public String getName() { return name; }
    public String getSubject() { return subject; }
    public String getQuery() { return query; }
    public String getOrderId() { return orderId; }
    public void setName(String name) { this.name = name; }
    public void setSubject(String subject) { this.subject = subject; }
    public void setQuery(String query) { this.query = query; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
} 