package com.mindx.serviceai.service;

import com.mindx.serviceai.dto.CreateTicketRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Initializes sample data on application startup.
 * Creates sample users and tickets for testing and demonstration.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);
    private final TicketService ticketService;

    public DataInitializer(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @Override
    public void run(String... args) throws Exception {
        log.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        log.info("📊 Initializing Sample Data for Demo...");
        log.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

        try {
            // Sample 1: Normal tracking query
            createSampleTicket(
                "Aarav Mehta",
                "1001",
                "Order Status",
                "Where is my order 101?"
            );

            // Sample 2: General delivery question
            createSampleTicket(
                "Sonali Rao",
                "202",
                "Delivery Information",
                "How long does standard shipping take? My order is 202."
            );

            // Sample 3: Tracking request for out-for-delivery
            createSampleTicket(
                "Harsh Patel",
                "303",
                "Track My Package",
                "Can you track order 303 for me? When will it arrive?"
            );

            // Sample 4: Escalation case - multiple issues
            createSampleTicket(
                "Kavya Reddy",
                "404",
                "Order Problem",
                "I'm very upset! I've been charged twice and my order 404 is delayed! This is unacceptable!"
            );

            // Sample 5: Account issue - should still get response
            createSampleTicket(
                "Neel Kulkarni",
                "505",
                "Account Help",
                "I forgot my password and cannot login to my account."
            );

            // Sample 6: Tracking with different phrasing
            createSampleTicket(
                "Priyanka Singh",
                "5678",
                "Package Status",
                "Can you check the status of order 5678? Ship date was yesterday."
            );

            // Sample 7: Damaged item escalation
            createSampleTicket(
                "Vikram Desai",
                "606",
                "Damaged Delivery",
                "The package arrived completely damaged! The item is destroyed. I need urgent help!"
            );

            // Sample 8: Simple greeting
            createSampleTicket(
                "Riya Joshi",
                "707",
                "Hello",
                "Hi, can you help me track my order 707?"
            );

            // Sample 9: Refund request - escalation
            createSampleTicket(
                "Aditya Sharma",
                "808",
                "Refund Request",
                "I want a full refund! The product doesn't match the description. This is fraud!"
            );

            // Sample 10: Warranty inquiry
            createSampleTicket(
                "Tamanna Gupta",
                "999",
                "Product Info",
                "Is my order 999 covered under 1 year warranty?"
            );

            log.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            log.info("✅ Sample Data Initialized Successfully!");
            log.info("📌 Total Tickets Created: 10");
            log.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            log.info("🌐 Access http://localhost:8080 to view the application");
            log.info("📋 Admin Dashboard: http://localhost:8080/admin");
            log.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        } catch (Exception e) {
            log.warn("⚠️  Error during data initialization: {}", e.getMessage());
            log.warn("This is normal for repeated runs. Moving forward...");
        }
    }

    private void createSampleTicket(String customerName, String orderId, String subject, String query) {
        try {
            CreateTicketRequest request = new CreateTicketRequest();
            request.setName(customerName);
            request.setOrderId(orderId);
            request.setSubject(subject);
            request.setQuery(query);

            ticketService.createTicket(request);
            log.info("✓ Created: {} - \"{}\"", customerName, subject);
        } catch (Exception e) {
            log.debug("Note: Could not create ticket for {}: {}", customerName, e.getMessage());
        }
    }
}
