@echo off
echo Checking if port 8080 is in use...
for /f "tokens=5" %%a in ('netstat -ano ^| findstr :8080') do (
    if not "%%a"=="" (
        echo Port 8080 is in use by PID %%a. Killing process...
        taskkill /PID %%a /F
    )
)
echo Starting Spring Boot application...
mvnw.cmd spring-boot:run