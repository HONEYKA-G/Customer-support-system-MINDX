# MindX Service AI - Quick Start Guide

## 🚀 Complete Project Overview

### What Is This Project?
MindX Service AI is a **4-day full-stack internship assignment** - a complete customer support system with:
- 💬 **Chat Interface**: Customers submit support requests
- 🤖 **AI Integration**: Automatic responses to queries
- 🚨 **Smart Escalation**: Human review for serious issues
- 📊 **Admin Dashboard**: Manage all customer tickets

**Key Innovation**: Uses keyword-based escalation to automatically flag urgent issues (refunds, complaints, fraud) for human agents.

---

## 📁 Project Structure

```
serviceai/
├── pom.xml                          (Maven config - shared root)
│
├── src/main/
│   ├── java/com/mindx/serviceai/
│   │   ├── ServiceaiApplication.java    (Main entry point)
│   │   ├── controller/
│   │   │   └── TicketController.java    (4 REST endpoints)
│   │   ├── service/
│   │   │   ├── TicketService.java       (Business logic)
│   │   │   ├── AiService.java           (OpenAI integration)
│   │   │   └── EscalationService.java   (Keyword detection)
│   │   ├── entity/
│   │   │   ├── User.java                (Customer info)
│   │   │   ├── Ticket.java              (Support ticket)
│   │   │   └── Message.java             (Chat message)
│   │   ├── repository/
│   │   │   ├── UserRepository.java
│   │   │   ├── TicketRepository.java
│   │   │   └── MessageRepository.java
│   │   └── dto/
│   │       ├── CreateTicketRequest.java
│   │       ├── TicketResponse.java
│   │       └── MessageResponse.java
│   └── resources/
│       └── application.properties        (H2 database config)
│
├── frontend/                         (React Vite app)
│   ├── src/
│   │   ├── App.jsx                  (Main component)
│   │   ├── pages/
│   │   │   ├── ChatPage.jsx         (Chat interface)
│   │   │   └── AdminDashboard.jsx   (Admin panel)
│   │   ├── services/
│   │   │   └── api.js               (API calls)
│   │   └── index.css                (Styling)
│   ├── package.json
│   └── vite.config.js
│
└── Documentation/
    ├── DATABASE_GUIDE.md            (Database explained)
    ├── SAMPLE_DATA.md               (Example data flows)
    ├── API_REFERENCE.md             (All endpoints)
    ├── SYSTEM_ARCHITECTURE.md       (Visual diagrams)
    ├── TESTING_GUIDE.md             (How to test)
    └── QUICK_START.md               (← You are here)
```

---

## ⚡ 5-Minute Quick Start

### Step 1: Start Backend (Terminal 1)
```bash
cd c:\Users\madhu\Downloads\serviceai

# Run Spring Boot server
mvn spring-boot:run
```

Expected output:
```
Started Applications in 3.5 seconds
Tomcat started on port(s): 8081
```

### Step 2: Start Frontend (Terminal 2)
```bash
cd c:\Users\madhu\Downloads\serviceai\frontend

# Install dependencies (first time only)
npm install

# Run development server
npm run dev
```

Expected output:
```
VITE v5.x.x
➜  Local:   http://localhost:5173/
```

### Step 3: Open in Browser
```
http://localhost:5173
```

### Step 4: Test Chat
1. Click **Chat** tab
2. Fill form:
   - Name: "Your Name"
   - Subject: "Test"
   - Message: "Hello"
3. Click **Send Message**
4. See AI response appear! ✅

### Step 5: Test Admin Dashboard
1. Click **Admin Dashboard** tab
2. See your ticket in the list
3. Click to view conversation
4. Change status to "RESOLVED"

**That's it! System is working!** 🎉

---

## 🔑 Key Technologies

```
Frontend:
├─ React 18 (UI library)
├─ Vite (build tool)
└─ Modern CSS (styling)

Backend:
├─ Java 21 (programming language)
├─ Spring Boot 3.2 (framework)
├─ Spring Data JPA (database)
└─ Hibernate (ORM)

Database:
├─ H2 (in-memory)
└─ Zero installation needed!

AI:
├─ OpenAI API (if configured)
└─ Mock responses (fallback)
```

---

## 🗄️ Database Explained (Simple Version)

```
H2 is an IN-MEMORY database:
├─ Runs in RAM (not on disk)
├─ Super fast
├─ No installation needed
├─ Data lost when server stops
└─ Perfect for demos!

It has 3 tables:

1. users (customers)
   ├─ id
   └─ name

2. tickets (support requests)
   ├─ id
   ├─ user_id (who created)
   ├─ subject
   ├─ query
   ├─ status (OPEN/NEEDS_HUMAN/RESOLVED)
   └─ created_at

3. messages (chat history)
   ├─ id
   ├─ ticket_id
   ├─ sender (USER/AI/ADMIN)
   ├─ message
   └─ timestamp
```

**Where is data stored?**
- While server running: **In RAM** (super fast!)
- After server stops: **Data cleared**
- On disk: **Nothing** (hence "in-memory")

---

## 🤖 How AI Works

### Normal Query (No Keywords)
```
Customer: "How long for shipping?"
  ↓
Backend checks: No escalation keywords
  ↓
Status = OPEN
  ↓
AiService responds: "Standard response..."
  ↓
Message stored with sender=AI
```

### Escalation Query (Problem Keywords)
```
Customer: "I want a REFUND! This is FRAUD!"
  ↓
Backend checks: Found "refund" + "fraud" keywords
  ↓
Status = NEEDS_HUMAN
  ↓
AiService skips, escalation message sent
  ↓
Admin sees yellow badge in dashboard
  ↓
Admin responds manually or marks RESOLVED
```

**Escalation Keywords**: refund, fraud, scam, lawyer, angry, furious, terrible, awful, hate, complaint, etc.

---

## 📊 API Endpoints (4 Total)

### 1. Create Ticket (Chat Form)
```
POST /api/tickets
{
  "name": "Rajesh Kumar",
  "subject": "Order Status",
  "query": "Where is my order?"
}

Response:
{
  "id": 1,
  "customerName": "Rajesh Kumar",
  "subject": "Order Status",
  "status": "OPEN",
  "messages": [
    {"sender": "USER", "message": "Where is my order?"},
    {"sender": "AI", "message": "Your order..."}
  ]
}
```

### 2. List All Tickets (Admin Dashboard)
```
GET /api/tickets

Response:
[
  {
    "id": 1,
    "customerName": "Rajesh Kumar",
    "subject": "Order Status",
    "status": "OPEN",
    "createdAt": "2026-04-08T10:15:23"
  },
  ...
]
```

### 3. Get Single Ticket (Detail View)
```
GET /api/tickets/1

Response:
{
  "id": 1,
  "customerName": "Rajesh Kumar",
  "status": "OPEN",
  "messages": [ ... ],
  ...
}
```

### 4. Update Ticket Status (Admin Change)
```
PATCH /api/tickets/1/status
{
  "status": "RESOLVED"
}

Response:
{
  "id": 1,
  "status": "RESOLVED",
  ...
}
```

---

## 🎨 UI Components

### Chat Page
```
┌─────────────────────────────┐
│  MindX Service AI           │
├────────────┬────────────────┤
│   Chat     │ Admin Dashboard│ ← Tab navigation
├─────────────────────────────┤
│ Name:      [___________]    │
│ Subject:   [___________]    │ ← Form to submit
│ Message:   [___________]    │
│            [Send Message]   │
├─────────────────────────────┤
│ USER: "Where is my order?"  │ ← Message bubbles
│ AI: "Your order is..."      │
└─────────────────────────────┘
```

### Admin Dashboard
```
┌──────────────────────────────────────────────┐
│  MindX Service AI                            │
├────────────┬────────────────────────────────┤
│   Chat     │ Admin Dashboard                │
├──────────────────────────────────────────────┤
│ Summary                                      │
│ Total: 5  │  Open: 2  │  Needs Human: 1 │  │
├──────────────────────────────────────────────┤
│ Search: [____]  Filter: [Status ▼]          │
├──────────────────┬────────────────────────────┤
│ Ticket List      │ Detail View               │
├──────────────────┼────────────────────────────┤
│ Rajesh Kumar     │ Ticket #1                 │
│ ✓ Shipping Info  │ Rajesh Kumar             │
│                  │ Subject: Shipping Info   │
│ Priya Sharma     │ Status: OPEN ▼           │
│ 🟡 Complaint     │ Messages:                │
│                  │ USER: "Where is...?"     │
│ Amit Patel       │ AI: "Your order..."      │
│ ✓ Product Info   │                          │
└──────────────────┴────────────────────────────┘
```

---

## 🧪 Quick Tests

### Test 1: Normal Query
```
Chat: "What are your hours?"
Expected: 
├─ AI responds
├─ Status: OPEN (blue badge)
└─ Shows in Admin: green ✓
```

### Test 2: Escalation
```
Chat: "I want my REFUND!"
Expected:
├─ No AI response
├─ Status: NEEDS_HUMAN (yellow badge)
└─ Shows in Admin: yellow 🟡
```

### Test 3: Admin Update
```
Admin: Click ticket → Change status → RESOLVED
Expected:
├─ Status changes
├─ Green RESOLVED badge appears
└─ Summary count updates
```

### Test 4: H2 Console
```
URL: http://localhost:8081/h2-console
Command: SELECT COUNT(*) FROM tickets;
Expected: Shows number of tickets created
```

---

## 🔒 Important Notes

### Security
- **Authentication**: Not implemented (optional enhancement)
- **Data**: No external database (H2 demo only)
- **API**: No auth tokens (public endpoints)
- **For Production**: Add Spring Security, use MySQL/PostgreSQL

### Performance
- **Speed**: Super fast (RAM-based)
- **Scalability**: 1 server instance only
- **Load**: Good for 10-100 concurrent users (demo)
- **Production**: Add load balancing, caching

### Data
- **Persistence**: Data lost on server restart
- **Backup**: No backup system
- **For Production**: Use persistent database + backups

---

## 📝 Documentation Files Reference

### 📖 DATABASE_GUIDE.md
**Read this if:** "How does the database work?"
- Complete explanation of H2
- Schema with all tables
- Sample data
- Data flow diagram

### 📖 SAMPLE_DATA.md
**Read this if:** "What gets stored in the database?"
- Real-world customer scenarios
- What fills each table
- Complete data examples
- SQL queries

### 📖 API_REFERENCE.md
**Read this if:** "What are all the API endpoints?"
- All 4 endpoints detailed
- Request/response examples
- Complete flow diagram
- Error handling

### 📖 SYSTEM_ARCHITECTURE.md
**Read this if:** "Show me the complete system visually"
- System architecture diagram
- Data flow diagram
- Customer journey
- Escalation logic

### 📖 TESTING_GUIDE.md
**Read this if:** "How do I test the system?"
- Step-by-step test cases
- Expected results
- H2 console SQL examples
- Troubleshooting guide

---

## 🚨 Troubleshooting

### Backend won't start
```
Issue: "Unable to find main class"
Solution: 
1. Make sure you're in: c:\Users\madhu\Downloads\serviceai
2. Run: mvn spring-boot:run
3. NOT in the nested serviceai/serviceai folder
```

### Frontend can't connect to backend
```
Issue: "Connection refused"
Solution:
1. Verify backend is running on port 8081
2. Check: netstat -a -n -o | findstr ":8081"
3. Should show: TCP 0.0.0.0:8081 LISTENING
```

### H2 console shows no data
```
Issue: "Tables are empty"
Solution:
1. Submit a chat message first
2. This creates the data
3. Then refresh H2 console
4. Data appears in tables
```

### AI responses look fake
```
Issue: "Mock responses appearing"
Solution:
1. OpenAI API key may be invalid
2. System falls back to mock responses
3. Both work correctly, mock is intentional fallback
```

---

## 🎯 Next Steps

### For Assignment Submission
1. ✅ Run application successfully
2. ✅ Test all features (chat + admin)
3. ✅ Screenshot the UI
4. ✅ Show database in H2 console
5. ✅ Explain architecture to professor

### Optional Enhancements
- Add user authentication/login
- Add email notifications
- Switch to MySQL database
- Add WebSocket for real-time updates
- Deploy to Azure/AWS
- Add file upload support
- Add search history

### For Production Release
- Setup MySQL database
- Add Spring Security (authentication)
- Add HTTPS/SSL
- Setup CI/CD pipeline (GitHub Actions)
- Add monitoring (logs, metrics)
- Scale to multiple servers

---

## 📞 Quick Reference

```
Backend URL:        http://localhost:8081
Frontend URL:       http://localhost:5173
H2 Console:         http://localhost:8081/h2-console

Start Backend:      mvn spring-boot:run
Start Frontend:     npm run dev (in /frontend)
Build Backend:      mvn clean package
Build Frontend:     npm run build

Database Type:      H2 (in-memory)
Tables:             users, tickets, messages
Default Status:     OPEN (no keywords), NEEDS_HUMAN (escalation)
Escalation Words:   refund, fraud, lawyer, angry, etc.
```

---

## ✨ Key Features Summary

| Feature | Status | Details |
|---------|--------|---------|
| Chat Interface | ✅ Complete | Customers submit support requests |
| AI Responses | ✅ Complete | OpenAI integration + mock fallback |
| Smart Escalation | ✅ Complete | Keyword detection triggers NEEDS_HUMAN |
| Admin Dashboard | ✅ Complete | View, search, filter, update tickets |
| Database | ✅ Complete | H2 in-memory with 3 tables |
| Error Handling | ✅ Complete | Global exception handler |
| UI/UX | ✅ Complete | Modern, responsive design |
| Frontend Build | ✅ Complete | Production-ready Vite build |
| Backend Build | ✅ Complete | Production-ready Maven JAR |

---

## 🎓 Learning Value

This project teaches:
- **Backend**: Spring Boot, JPA/Hibernate, REST APIs
- **Frontend**: React, component lifecycle, API integration
- **Database**: Schema design, relationships, queries
- **Architecture**: Layered design, separation of concerns
- **Full Stack**: Complete flow from UI to database
- **Problem Solving**: Escalation logic, error handling
- **Best Practices**: Exception handling, DTOs, repositories

---

## 🏆 Assignment Completion Checklist

```
✅ Day 1: Backend APIs (4 endpoints)
✅ Day 2: AI Integration + Escalation
✅ Day 3: React Chat Interface
✅ Day 4: Admin Dashboard + Features
✅ + Bonus: Modern UI/UX Enhancement
✅ + Bonus: Comprehensive Documentation

Assignment Status: COMPLETE 🎉
```

---

## 📞 Support

**Need Help?**
1. Check TESTING_GUIDE.md for test cases
2. Check DATABASE_GUIDE.md for DB questions
3. Check API_REFERENCE.md for endpoint details
4. Check H2 console for data verification
5. Check backend logs for errors

**Everything should work!** If not, verify:
- Both servers running (8081 + 5173)
- No errors in terminal
- Browser console clear of errors
- H2 has data (submit chat first)

---

## 🎉 You're All Set!

Your MindX Service AI system is:
- ✅ Fully functional
- ✅ Production-quality code
- ✅ Professional UI/UX
- ✅ Comprehensively documented
- ✅ Ready for assignment submission

**Enjoy!** 🚀
