# MindX Service AI - Database Architecture & Data Flow

## Database Overview

### What Database is Being Used?

**H2 Database** (in-memory):
- **H2** is a lightweight, zero-configuration database
- It runs **entirely in RAM** (memory) - no installation needed
- Perfect for demos, development, and testing
- When you stop the backend, all data is automatically cleared

### Where is Data Stored?

```
Backend Server (RAM)
    ↓
H2 In-Memory Database
    ↓
Tables: users, tickets, messages
    ↓
(Lost when server stops)
```

**Location**: `C:\Users\madhu\Downloads\serviceai\src\main\resources\application.properties`

```properties
spring.datasource.url=jdbc:h2:mem:mindx_db;DB_CLOSE_DELAY=-1;DB_CLOSE_ON_EXIT=FALSE
spring.datasource.driver-class-name=org.h2.Driver
```

---

## Database Schema (3 Tables)

### Table 1: `users`

Stores customer information.

```sql
CREATE TABLE users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL
);
```

**Purpose**: Track unique customers

**Sample Data**:
```
| id | name           |
|----+----------------|
| 1  | Rajesh Kumar   |
| 2  | Priya Sharma   |
| 3  | Amit Patel     |
| 4  | Neha Singh     |
```

---

### Table 2: `tickets`

Stores support tickets (main entity).

```sql
CREATE TABLE tickets (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT,
    subject VARCHAR(255),
    query TEXT,
    status VARCHAR(50),
    created_at DATETIME
);
```

**Fields**:
- `id`: Unique ticket identifier
- `user_id`: Links to `users` table (who raised the ticket)
- `subject`: Short subject line (e.g., "Order Issue")
- `query`: Full problem description
- `status`: One of `OPEN`, `NEEDS_HUMAN`, `RESOLVED`
- `created_at`: When the ticket was created

**Sample Data**:
```
| id | user_id | subject              | query                              | status      | created_at          |
|----|---------|----------------------|------------------------------------|-------------|---------------------|
| 1  | 1       | Order Not Arrived    | My order #12345 hasn't arrived     | OPEN        | 2026-04-08 10:15:00 |
| 2  | 2       | Refund Request       | I want a refund for my order       | NEEDS_HUMAN | 2026-04-08 10:20:00 |
| 3  | 3       | Product Quality      | The product is damaged             | NEEDS_HUMAN | 2026-04-08 10:25:00 |
| 4  | 4       | Delivery Tracking    | Can I track my delivery?           | RESOLVED    | 2026-04-08 09:00:00 |
```

---

### Table 3: `messages`

Stores conversation between customer, AI, and admin.

```sql
CREATE TABLE messages (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    ticket_id BIGINT,
    sender VARCHAR(50),
    message TEXT,
    timestamp DATETIME
);
```

**Fields**:
- `id`: Unique message identifier
- `ticket_id`: Links to `tickets` table (which ticket this belongs to)
- `sender`: Who sent the message - `USER`, `AI`, or `ADMIN`
- `message`: The actual message content
- `timestamp`: When the message was sent

**Sample Data** (for Ticket #1):
```
| id | ticket_id | sender | message                                      | timestamp           |
|----|-----------|--------|----------------------------------------------|---------------------|
| 1  | 1         | USER   | My order #12345 hasn't arrived               | 2026-04-08 10:15:00 |
| 2  | 1         | AI     | Please provide your order ID for tracking    | 2026-04-08 10:15:05 |
| 3  | 1         | USER   | Order ID is MX-2026-001234                  | 2026-04-08 10:16:00 |
| 4  | 1         | AI     | Your order is in transit. Arrives by Apr 10 | 2026-04-08 10:16:05 |
```

**Sample Data** (for Ticket #2 - Escalated):
```
| id | ticket_id | sender | message                                      | timestamp           |
|----|-----------|--------|----------------------------------------------|---------------------|
| 5  | 2         | USER   | I want a refund for my order                 | 2026-04-08 10:20:00 |
| 6  | 2         | AI     | Your query flagged for human review          | 2026-04-08 10:20:05 |
```

---

## How Data Flows Through the System

### Customer Chat Flow

```
1. Customer fills form (Chat Page)
   ↓
2. Name: "Rajesh Kumar"
   Subject: "Order Not Arrived"
   Query: "My order hasn't arrived yet"
   ↓
3. Backend creates:
   - User (if new): INSERT INTO users (name) VALUES ('Rajesh Kumar')
   - Ticket: INSERT INTO tickets (user_id, subject, query, status, created_at) 
   - Message (USER): INSERT INTO messages (ticket_id, sender, message, timestamp)
   ↓
4. AI processes query (checks for escalation keywords)
   - No escalation keywords → status = OPEN
   - Has "refund" → status = NEEDS_HUMAN
   ↓
5. AI generates response:
   - Message (AI): INSERT INTO messages (ticket_id, sender, message, timestamp)
   ↓
6. Response sent back to customer (Chat Page displays)
```

### Admin Dashboard Flow

```
1. Admin views dashboard
   ↓
2. Backend fetches:
   SELECT t.*, u.name FROM tickets t 
   LEFT JOIN users u ON t.user_id = u.id
   ORDER BY t.created_at DESC
   ↓
3. For each ticket, fetch messages:
   SELECT * FROM messages WHERE ticket_id = ? ORDER BY timestamp ASC
   ↓
4. Display in table:
   - Ticket ID
   - Customer name
   - Subject
   - Status (with color badge)
   - Created time
   ↓
5. Admin clicks ticket → details page shows:
   - Full conversation (all messages)
   - Status dropdown (can change OPEN → RESOLVED)
   ↓
6. Admin changes status:
   UPDATE tickets SET status = 'RESOLVED' WHERE id = ?
```

---

## Status Meanings

| Status      | Meaning                                   | Trigger                      |
|-------------|-------------------------------------------|------------------------------|
| `OPEN`      | Waiting for automated AI response         | Default for normal queries   |
| `NEEDS_HUMAN` | Requires human agent intervention        | Keywords: refund, complaint, angry, fraud, lawsuit, etc. |
| `RESOLVED`  | Issue resolved, ticket closed             | Admin manually updates       |

---

## Sample Complete Conversation

### Scenario: Customer reports missing order (Escalation Case)

**Customer (Name: Rajesh Kumar)**
```
Subject: Where is my order?
Query: I ordered something 2 weeks ago and still haven't received it. This is unacceptable!
```

**Backend Process**:
1. Detects escalation keyword: "unacceptable"
2. Sets status: `NEEDS_HUMAN` (not OPEN)
3. Stores messages:

**Messages Table**:
```
Message 1 (USER):  "I ordered something 2 weeks ago and still haven't received it. This is unacceptable!"
Message 2 (AI):    "Your query has been flagged for review by our support team. A human agent will get back to you shortly."
```

**In Admin Dashboard**:
```
Ticket #5
Customer: Rajesh Kumar
Subject: Where is my order?
Status: 🟨 NEEDS_HUMAN (yellow badge)
Created: 2026-04-08 10:45:00

Conversation:
USER (10:45:00):   "I ordered something 2 weeks ago..."
AI (10:45:05):     "Your query has been flagged..."

[Admin can now change status to RESOLVED or monitor]
```

---

## How to View the Database

### Option 1: H2 Console (Web UI)

When backend is running:
1. Open browser: `http://localhost:8081/h2-console`
2. Connection settings:
   - **JDBC URL**: `jdbc:h2:mem:mindx_db`
   - **Username**: `sa`
   - **Password**: (leave blank)
3. Click "Connect"
4. Run SQL:
   ```sql
   SELECT * FROM users;
   SELECT * FROM tickets;
   SELECT * FROM messages;
   ```

### Option 2: Backend Logs

Spring Boot logs SQL queries. Check terminal output for:
```
Hibernate: select user0_.id, user0_.name from users user0_
Hibernate: insert into messages (sender, ticket_id, message, timestamp) values (?, ?, ?, ?)
```

---

## Important Notes

### ⚠️ Data is Temporary
- Data exists ONLY while backend is running
- When you stop the server (`Ctrl+C`), **all data is erased**
- Next restart = fresh database

### ✅ Perfect for Demo
- No database installation needed
- No credentials needed
- No external setup
- Fully self-contained

### 🔄 For Production

To use a real database (MySQL/PostgreSQL):

Update `application.properties`:
```properties
# MySQL Example
spring.datasource.url=jdbc:mysql://localhost:3306/mindx_db?createDatabaseIfNotExist=true
spring.datasource.username=root
spring.datasource.password=yourpassword
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.jpa.hibernate.ddl-auto=update
```

Then Hibernate will:
1. Connect to your MySQL database
2. Create tables automatically
3. Persist data permanently

---

## Example Complete Data Set

### After running the app with sample interactions:

**users table**:
```
1 | John Doe
2 | Sarah Smith
3 | Amit Kumar
```

**tickets table**:
```
1 | 1 | Delivery Issue      | Where is my order?           | OPEN        | 2026-04-08 10:00:00
2 | 2 | Refund Query        | I want my money back         | NEEDS_HUMAN | 2026-04-08 10:05:00
3 | 3 | Account Problem     | Can't login to my account    | RESOLVED    | 2026-04-08 09:30:00
```

**messages table**:
```
1 | 1 | USER  | Where is my order?                          | 2026-04-08 10:00:00
2 | 1 | AI    | Please share your order ID for tracking     | 2026-04-08 10:00:05
3 | 1 | USER  | Order ID is ABC123                          | 2026-04-08 10:01:00
4 | 1 | AI    | Order in transit, arrives Apr 10            | 2026-04-08 10:01:05
5 | 2 | USER  | I want my money back                         | 2026-04-08 10:05:00
6 | 2 | AI    | Your query flagged for human review          | 2026-04-08 10:05:05
7 | 3 | USER  | Can't login to my account                    | 2026-04-08 09:30:00
8 | 3 | AI    | Visit password reset page                    | 2026-04-08 09:30:05
9 | 3 | ADMIN | Reset link sent to your email                | 2026-04-08 10:15:00
```

---

## Summary

```
┌─────────────────────────────────────────────────────────────┐
│             MindX Service AI Data Architecture              │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Customer Chat      →  Backend API  →  H2 In-Memory DB     │
│                         (Spring)         (RAM)              │
│                            ↓              ↓                 │
│                      Stores in 3 tables:                    │
│                      • users                                │
│                      • tickets                              │
│                      • messages                             │
│                            ↓                                │
│  Admin Dashboard  ←  Backend Query  ←  Display from DB     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Quick Reference

**What fills each table?**
- **users**: Customer names (created when first ticket submitted)
- **tickets**: Support requests (created from chat form)
- **messages**: Chat messages (created for each USER message + AI response)

**How long does data stay?**
- Server running = data exists in RAM
- Server stopped = data deleted

**Can I change the database?**
- Yes! Update `application.properties` with MySQL/PostgreSQL config
- Hibernate auto-creates tables on startup
