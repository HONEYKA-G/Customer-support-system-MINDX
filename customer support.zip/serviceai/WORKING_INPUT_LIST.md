# 🚀 Working Input List - Service AI Demo Data

## ✅ Status: All Sample Data Ready & Working

Your application now has **10 pre-loaded sample users** with realistic queries that will trigger perfect AI responses! The system automatically initializes these on startup.

---

## 📋 Sample Users & Queries (Ready to Test)

### **User 1: Aarav Mehta**
**Order ID:** 1001  
**Subject:** Order Status  
**Query:** `Where is my order 101?`  
**Expected AI Response:**  
```
Order #101 is currently In Transit. Last scanned at Mumbai Hub. 
Estimated delivery: 2026-04-14. Your order left the distribution 
center and is on route.
```
**Status in DB:** OPEN (AI will respond automatically)

---

### **User 2: Sonali Rao**
**Order ID:** 202  
**Subject:** Delivery Information  
**Query:** `How long does standard shipping take? My order is 202.`  
**Expected AI Response:**  
```
Order #202 is currently Delivered. Last scanned at Bengaluru 
Delivery Center. Estimated delivery: 2026-04-12. Your package 
was delivered successfully and signed for.
```
**Status in DB:** OPEN (Normal tracking response)

---

### **User 3: Harsh Patel**
**Order ID:** 303  
**Subject:** Track My Package  
**Query:** `Can you track order 303 for me? When will it arrive?`  
**Expected AI Response:**  
```
Order #303 is currently Out for Delivery. Last scanned at Delhi 
Local Facility. Estimated delivery: 2026-04-13. Your order is 
out for delivery and should arrive today.
```
**Status in DB:** OPEN

---

### **User 4: Kavya Reddy** ⚠️ (Escalation Case)
**Order ID:** 404  
**Subject:** Order Problem  
**Query:** `I'm very upset! I've been charged twice and my order 404 is delayed! This is unacceptable!`  
**Expected AI Response:**  
```
Your query has been flagged for review by our support team. 
A human agent will get back to you shortly.
```
**Status in DB:** NEEDS_HUMAN (Keywords: "upset", "charged twice", "delayed" → Escalated)  
**Admin Action Needed:** Yes - Visit Admin Dashboard to review and resolve

---

### **User 5: Neel Kulkarni**
**Order ID:** 505  
**Subject:** Account Help  
**Query:** `I forgot my password and cannot login to my account.`  
**Expected AI Response:**  
```
For account or login issues, please visit our password reset page 
at mindx.com/reset-password or reply with your registered email so 
I can send a reset link.
```
**Status in DB:** OPEN (Auto-resolved by AI)

---

### **User 6: Priyanka Singh**
**Order ID:** 5678  
**Subject:** Package Status  
**Query:** `Can you check the status of order 5678? Ship date was yesterday.`  
**Expected AI Response:**  
```
Order #5678 is currently In Transit. Last scanned at Ahmedabad Hub. 
Estimated delivery: 2026-04-15. Your package is moving to your area.
```
**Status in DB:** OPEN (Tracking info recognized and provided)

---

### **User 7: Vikram Desai** ⚠️ (Escalation Case)
**Order ID:** 606  
**Subject:** Damaged Delivery  
**Query:** `The package arrived completely damaged! The item is destroyed. I need urgent help!`  
**Expected AI Response:**  
```
Your query has been flagged for review by our support team. 
A human agent will get back to you shortly.
```
**Status in DB:** NEEDS_HUMAN (Keywords: "damaged", "destroyed", "urgent" → Escalated)  
**Admin Action Needed:** Yes - High priority damage claim

---

### **User 8: Riya Joshi**
**Order ID:** 707  
**Subject:** Hello  
**Query:** `Hi, can you help me track my order 707?`  
**Expected AI Response:**  
```
Order #707 is currently In Transit. Last scanned at Hyderabad Hub. 
Estimated delivery: 2026-04-14. Your order is moving through the 
delivery network.
```
**Status in DB:** OPEN (Friendly greeting + tracking)

---

### **User 9: Aditya Sharma** ⚠️ (Escalation Case)
**Order ID:** 808  
**Subject:** Refund Request  
**Query:** `I want a full refund! The product doesn't match the description. This is fraud!`  
**Expected AI Response:**  
```
Your query has been flagged for review by our support team. 
A human agent will get back to you shortly.
```
**Status in DB:** NEEDS_HUMAN (Keywords: "refund", "fraud" → Escalated)  
**Admin Action Needed:** Yes - Review product complaint and fraud claim

---

### **User 10: Tamanna Gupta**
**Order ID:** 999  
**Subject:** Product Info  
**Query:** `Is my order 999 covered under 1 year warranty?`  
**Expected AI Response:**  
```
Thank you for reaching out to MindX Support. I've received your query 
and will do my best to help. Could you please provide more details so 
I can assist you better?
```
**Status in DB:** OPEN (Generic response - no specific warranty data configured)

---

## 📊 Database Records Summary

| User ID | Customer Name | Order ID | Subject | Status | AI Handled? |
|---------|---|---|---|---|---|
| 1 | Aarav Mehta | 1001 | Order Status | OPEN | ✓ Yes |
| 2 | Sonali Rao | 202 | Delivery Info | OPEN | ✓ Yes |
| 3 | Harsh Patel | 303 | Track Package | OPEN | ✓ Yes |
| 4 | Kavya Reddy | 404 | Order Problem | NEEDS_HUMAN | ✗ Escalated |
| 5 | Neel Kulkarni | 505 | Account Help | OPEN | ✓ Yes |
| 6 | Priyanka Singh | 5678 | Package Status | OPEN | ✓ Yes |
| 7 | Vikram Desai | 606 | Damaged | NEEDS_HUMAN | ✗ Escalated |
| 8 | Riya Joshi | 707 | Hello | OPEN | ✓ Yes |
| 9 | Aditya Sharma | 808 | Refund Request | NEEDS_HUMAN | ✗ Escalated |
| 10 | Tamanna Gupta | 999 | Warranty | OPEN | ✓ Yes |

---

## 🎯 How This Works (Step-by-Step)

### **On Application Start-Up:**
1. Spring Boot initializes the app
2. `DataInitializer` component runs automatically
3. Creates 10 sample tickets with these exact users and queries
4. AI generates responses for each based on:
   - Order tracking data (if order ID exists in system)
   - Escalation keywords (angry, fraud, refund, damaged, etc.)
   - Generic intelligent responses

### **In Your Database (H2):**

**users table:** 10 users stored with their names  
**tickets table:** 10 tickets with status (OPEN or NEEDS_HUMAN)  
**messages table:** 20 messages (10 user messages + 10 AI responses)

### **When You View Admin Dashboard:**
- 7 tickets will show as "OPEN" (AI handled)
- 3 tickets will show as "NEEDS_HUMAN" (escalated for admin review)
- All conversations visible with timestamps

---

## 🧪 Testing Instructions

### **Option 1: View in Web Frontend**
1. Open `http://localhost:8080` in browser
2. Scroll down to see the admin dashboard
3. Click on "View All Tickets" or "Admin Dashboard"
4. See all 10 pre-loaded tickets with conversations

### **Option 2: Test via API Endpoint**

**Get all tickets:**
```bash
curl http://localhost:8080/api/tickets
```

**View specific user's ticket:**
```bash
curl http://localhost:8080/api/tickets/1
```

**View Admin Dashboard:**
```bash
curl http://localhost:8080/admin
```

### **Option 3: Test H2 Database Console**
1. Open `http://localhost:8080/h2-console`
2. JDBC URL: `jdbc:h2:mem:mindx_db`
3. User: `sa`
4. Password: (leave blank)
5. Run SQL queries to explore:

```sql
-- See all users
SELECT * FROM users;

-- See all tickets
SELECT * FROM tickets ORDER BY created_at DESC;

-- See all messages for a specific ticket
SELECT * FROM messages WHERE ticket_id = 1 ORDER BY timestamp ASC;

-- Count escalated tickets
SELECT COUNT(*) FROM tickets WHERE status = 'NEEDS_HUMAN';
```

---

## 🔄 AI Response Logic (How It Works)

### **For Tracking Queries:**
User asks: "Where is my order 101?"
1. System extracts Order ID: 101
2. Looks up in OrderTrackingService (has 100 orders configured)
3. Returns exact tracking status: "In Transit, at Mumbai Hub..."
4. Ticket status: **OPEN**

### **For Escalation Queries:**
User asks: "I'm very angry and want a refund!"
1. Detects keywords: "angry", "refund"
2. Sets ticket status: **NEEDS_HUMAN**
3. Returns: "Your query flagged for human agent"
4. Admin can manually review and respond

### **For Generic Queries:**
User asks: "Is there warranty?"
1. No tracking data, no escalation keywords
2. Returns helpful generic response
3. Ticket status: **OPEN**

---

## 📦 Available Order IDs (Database Pre-Loaded)

These order IDs will return tracking information:

| Order ID | Status | Location | Delivery Date | Description |
|---|---|---|---|---|
| 101 | In Transit | Mumbai Hub | 2026-04-14 | Order left distribution center |
| 202 | Delivered | Bengaluru DC | 2026-04-12 | Package delivered & signed |
| 303 | Out for Delivery | Delhi Local | 2026-04-13 | Arriving today |
| 404 | Processing | Pune Warehouse | 2026-04-16 | Being packed |
| 505 | Shipped | Chennai Hub | 2026-04-15 | In transit network |
| 606 | Delivered | Kolkata DC | 2026-04-11 | Delivered 2 days ago |
| 707 | In Transit | Hyderabad Hub | 2026-04-14 | Moving through network |
| 808 | Out for Delivery | Jaipur Local | 2026-04-13 | Delivery by EOD |
| 5678 | In Transit | Ahmedabad Hub | 2026-04-15 | Moving to area |
| 999 | (No data) | - | - | Will show "not found" |

---

## ⚙️ How Database Connection Works

### **Connection Flow:**
```
User Submits Query
    ↓
Controller receives request
    ↓
TicketService.createTicket()
    ↓
Saved to H2 Database (in-memory)
    ↓
OrderTrackingService checks order data
    ↓
AiService generates response
    ↓
Response saved to database
    ↓
Returned to user
```

### **Database Storage:**
- **Location:** In-memory (RAM) - fast & ephemeral
- **Connection:** JPA/Hibernate ORM
- **Config File:** `src/main/resources/application.properties`
- **Tables Auto-Created:** When app starts

```properties
# In application.properties:
spring.datasource.url=jdbc:h2:mem:mindx_db
spring.jpa.hibernate.ddl-auto=create-drop  # Auto-create tables
```

### **Data Persistence:**
- On each app restart, data is **CLEARED** and **RE-INITIALIZED**
- Perfect for demos & testing
- For production: Switch to MySQL/PostgreSQL in config

---

## 🎓 For Your Interview/Presentation

### **What to Demonstrate:**
1. **Show App Starting:** Terminal shows "✅ Sample Data Initialized Successfully!"
2. **Show Web Interface:** 10 tickets visible, user conversations shown
3. **Show Admin Dashboard:** Mark escalated tickets as resolved
4. **Explain the Flow:** "When users ask for order tracking, the AI instantly provides location and delivery details from our database..."
5. **Show H2 Console:** Open database, show tables, run SQL queries
6. **Mention:** "The system intelligently detects urgent issues and escalates to human agents"

### **Key Talking Points:**
- "10 users created automatically on startup"
- "AI responds differently based on query content"
- "Escalation system works for angry customers"
- "Order tracking integrated with AI responses"
- "Database stores everything - users, conversations, tracking info"

---

## ✅ Verification Checklist

- [x] Application starts without errors
- [x] 10 sample users created on startup
- [x] 10 tickets created in database
- [x] AI responds with tracking info
- [x] Escalation detected and tickets marked NEEDS_HUMAN
- [x] Admin dashboard shows all tickets
- [x] H2 database accessible at /h2-console
- [x] No build failures
- [x] App runs on single shot (mvnw.cmd spring-boot:run)

---

## 🚀 Quick Start Commands

**Start Application:**
```bash
cd c:\Users\madhu\Downloads\serviceai\serviceai
mvnw.cmd spring-boot:run
```

**Access in Browser:**
- Main App: `http://localhost:8080`
- Admin Dashboard: `http://localhost:8080/admin`
- Database Console: `http://localhost:8080/h2-console`

**That's it! Everything works automatically.** ✨

---

## 📞 Support

If you need to:
- **Add more users:** Edit `DataInitializer.java`
- **Add more orders:** Edit `OrderTrackingService.java`
- **Change escalation keywords:** Edit `EscalationService.java`
- **View raw data:** Use H2 Console
- **Debug responses:** Check server logs in terminal

Your application is **production-ready for demo** with realistic, pre-loaded data! 🎉
