# Database Sample Data - Customer Support Examples

## Scenario 1: Normal Support Query (Auto-Resolved by AI)

### What Customer Fills in Chat:
```
Name:    "Priya Sharma"
Subject: "Delivery Time"
Query:   "Hello, how long does standard shipping take?"
```

### What Gets Stored in Database:

**users table (NEW ENTRY)**:
```
id = 1
name = "Priya Sharma"
```

**tickets table (NEW ENTRY)**:
```
id = 1
user_id = 1
subject = "Delivery Time"
query = "Hello, how long does standard shipping take?"
status = "OPEN"  ← No escalation keywords found
created_at = 2026-04-08 10:15:23
```

**messages table (TWO ENTRIES)**:
```
Entry 1:
  id = 1
  ticket_id = 1
  sender = "USER"
  message = "Hello, how long does standard shipping take?"
  timestamp = 2026-04-08 10:15:23

Entry 2:
  id = 2
  ticket_id = 1
  sender = "AI"
  message = "Delivery times vary by location. Standard shipping takes 3-5 business days. Please share your order number to get a real-time tracking update."
  timestamp = 2026-04-08 10:15:28
```

### What Customer Sees in Chat:
```
┌─ Ticket #1 ─────────────────────────────────────┐
│                                                  │
│ Delivery Time                        🟦 OPEN    │
│ Priya Sharma • 2026-04-08 10:15:23             │
│                                                  │
│ USER (10:15:23)                                 │
│ Hello, how long does standard shipping take?   │
│                                                  │
│ AI (10:15:28)                                   │
│ Delivery times vary by location...              │
│                                                  │
└──────────────────────────────────────────────────┘
```

---

## Scenario 2: Escalation Case (Human Review Needed)

### What Customer Fills in Chat:
```
Name:    "Rajesh Kumar"
Subject: "Order Complaint"
Query:   "I am VERY angry! This order is a FRAUD and I want a REFUND immediately!"
```

### What Gets Stored in Database:

**users table (NEW ENTRY)**:
```
id = 2
name = "Rajesh Kumar"
```

**tickets table (NEW ENTRY)**:
```
id = 2
user_id = 2
subject = "Order Complaint"
query = "I am VERY angry! This order is a FRAUD and I want a REFUND immediately!"
status = "NEEDS_HUMAN"  ← Keywords detected: "angry", "fraud", "refund"
created_at = 2026-04-08 10:30:45
```

**messages table (TWO ENTRIES)**:
```
Entry 1:
  id = 3
  ticket_id = 2
  sender = "USER"
  message = "I am VERY angry! This order is a FRAUD and I want a REFUND immediately!"
  timestamp = 2026-04-08 10:30:45

Entry 2:
  id = 4
  ticket_id = 2
  sender = "AI"
  message = "Your query has been flagged for review by our support team. A human agent will get back to you shortly."
  timestamp = 2026-04-08 10:30:50
```

### What Admin Sees in Dashboard:
```
┌─ Tickets Table ──────────────────────────────────────────────┐
│ ID │ Customer      │ Subject         │ Status        │ Time  │
├────┼───────────────┼─────────────────┼───────────────┼───────┤
│ 2  │ Rajesh Kumar  │ Order Complaint │ 🟨 NEEDS_HUMAN│ 10:30 │
│ 1  │ Priya Sharma  │ Delivery Time   │ 🟦 OPEN       │ 10:15 │
└──────────────────────────────────────────────────────────────┘

ADMIN CLICKS TICKET #2 → DETAIL VIEW:

┌─ Ticket #2 – Order Complaint ────────────────────────────────┐
│                                          🟨 NEEDS_HUMAN       │
│ Customer: Rajesh Kumar                                        │
│ Created: 2026-04-08 10:30:45                                 │
│                                                               │
│ CONVERSATION:                                                 │
│                                                               │
│ USER (10:30:45)                                              │
│ "I am VERY angry! This order is a FRAUD..."                 │
│                                                               │
│ AI (10:30:50)                                                │
│ "Your query has been flagged for review..."                 │
│                                                               │
│ [Admin can read & take action]                               │
│ Status: [OPEN ▼ | NEEDS_HUMAN ✓ | RESOLVED ▼]              │
└──────────────────────────────────────────────────────────────┘
```

---

## Scenario 3: Admin Takes Action (Status Update)

### Admin Changes Status from NEEDS_HUMAN to RESOLVED

**Database Update**:
```
UPDATE tickets SET status = 'RESOLVED' WHERE id = 2;
```

**tickets table (UPDATED)**:
```
id = 2
user_id = 2
subject = "Order Complaint"
query = "I am VERY angry! This order is a FRAUD and I want a REFUND immediately!"
status = "RESOLVED"  ← Changed from NEEDS_HUMAN to RESOLVED
created_at = 2026-04-08 10:30:45
```

**messages table** (unchanged, but admin could add a message):
```
Entry 3 (Optional - Admin adds note):
  id = 5
  ticket_id = 2
  sender = "ADMIN"
  message = "Refund processed. Your refund of $49.99 has been initiated and will reflect in 3-5 business days."
  timestamp = 2026-04-08 11:00:00
```

---

## Complete 3-Table View After Multiple Customer Interactions

### users Table
```
┌────┬─────────────────┐
│ id │ name            │
├────┼─────────────────┤
│ 1  │ Priya Sharma    │
│ 2  │ Rajesh Kumar    │
│ 3  │ Amit Patel      │
│ 4  │ Neha Singh      │
│ 5  │ Vikram Gupta    │
└────┴─────────────────┘
```

### tickets Table
```
┌────┬────────┬──────────────────┬────────────────────────┬──────────────┬────────────────────────┐
│ id │user_id│ subject          │ query                  │ status       │ created_at             │
├────┼────────┼──────────────────┼────────────────────────┼──────────────┼────────────────────────┤
│ 1  │ 1     │ Delivery Time    │ How long for shipping?│ OPEN         │ 2026-04-08 10:15:23   │
│ 2  │ 2     │ Order Complaint  │ I want a REFUND!     │ RESOLVED     │ 2026-04-08 10:30:45   │
│ 3  │ 3     │ Account Issue    │ Can't reset password │ NEEDS_HUMAN  │ 2026-04-08 10:45:00   │
│ 4  │ 4     │ Product Quality  │ Item is damaged       │ OPEN         │ 2026-04-08 11:00:12   │
│ 5  │ 5     │ Billing Problem  │ Charged twice!        │ NEEDS_HUMAN  │ 2026-04-08 11:15:33   │
└────┴────────┴──────────────────┴────────────────────────┴──────────────┴────────────────────────┘
```

### messages Table
```
┌────┬────────────┬────────┬─────────────────────────────────────────────────┬────────────────────────┐
│ id │ ticket_id  │ sender │ message                                         │ timestamp              │
├────┼────────────┼────────┼─────────────────────────────────────────────────┼────────────────────────┤
│ 1  │ 1          │ USER   │ How long for shipping?                          │ 2026-04-08 10:15:23   │
│ 2  │ 1          │ AI     │ Standard shipping takes 3-5 business days       │ 2026-04-08 10:15:28   │
│ 3  │ 2          │ USER   │ I want a REFUND!                                │ 2026-04-08 10:30:45   │
│ 4  │ 2          │ AI     │ Your query flagged for human review             │ 2026-04-08 10:30:50   │
│ 5  │ 2          │ ADMIN  │ Refund approved. Check email for confirmation   │ 2026-04-08 11:00:00   │
│ 6  │ 3          │ USER   │ Can't reset my password                         │ 2026-04-08 10:45:00   │
│ 7  │ 3          │ AI     │ Visit password reset page at site.com/reset     │ 2026-04-08 10:45:05   │
│ 8  │ 4          │ USER   │ My item arrived damaged                         │ 2026-04-08 11:00:12   │
│ 9  │ 4          │ AI     │ Please provide photos for replacement pickup    │ 2026-04-08 11:00:17   │
│ 10 │ 5          │ USER   │ I was charged twice for same order!             │ 2026-04-08 11:15:33   │
│ 11 │ 5          │ AI     │ Your concern escalated for billing review       │ 2026-04-08 11:15:38   │
└────┴────────────┴────────┴─────────────────────────────────────────────────┴────────────────────────┘
```

---

## Data Relationships (Explained)

### One Customer → Multiple Tickets

```
User: Priya Sharma (user_id = 1)
  ├─ Ticket #1: "Delivery Time" (status = OPEN)
  └─ Ticket #99: "Return Request" (status = RESOLVED)
     [If same customer asks again later]
```

### One Ticket → Multiple Messages

```
Ticket #2: "Order Complaint" (ticket_id = 2)
  ├─ Message #3: USER → "I want a REFUND!"
  ├─ Message #4: AI → "Your query flagged for human review"
  └─ Message #5: ADMIN → "Refund processed successfully"
```

---

## SQL Queries to Understand the Data

### Get all tickets for a customer:
```sql
SELECT t.* FROM tickets t
WHERE t.user_id = 1;
```

### Get full conversation for a ticket:
```sql
SELECT m.* FROM messages m
WHERE m.ticket_id = 2
ORDER BY m.timestamp ASC;
```

### Get all escalated (NEEDS_HUMAN) tickets:
```sql
SELECT * FROM tickets
WHERE status = 'NEEDS_HUMAN'
ORDER BY created_at DESC;
```

### Get tickets created today:
```sql
SELECT t.*, u.name FROM tickets t
LEFT JOIN users u ON t.user_id = u.id
WHERE DATE(t.created_at) = CURDATE()
ORDER BY t.created_at DESC;
```

---

## 10 Quick Sample Ticket Entries

1. Name: Aarav Mehta
   Subject: "Missing order"
   Query: "I placed an order yesterday and it has not arrived. Please check."
   Expected status: OPEN / AI response with shipping follow-up.

2. Name: Sonali Rao
   Subject: "Wrong item delivered"
   Query: "I received the wrong product, can you replace it?"
   Expected status: NEEDS_HUMAN / AI suggests return review.

3. Name: Harsh Patel
   Subject: "Cancel order"
   Query: "Cancel my order before it ships. Order number 5678."
   Expected status: NEEDS_HUMAN / AI asks for cancellation details.

4. Name: Kavya Reddy
   Subject: "Payment issue"
   Query: "I paid twice for one order. Please refund one payment."
   Expected status: NEEDS_HUMAN / AI flags billing review.

5. Name: Neel Kulkarni
   Subject: "Account login problem"
   Query: "I cannot log into my account after the password reset."
   Expected status: OPEN / AI tries basic troubleshooting.

6. Name: Priyanka Singh
   Subject: "Shipping delay"
   Query: "My order is delayed more than promised date. Why?"
   Expected status: OPEN / AI explains shipping and asks order ID.

7. Name: Vikram Desai
   Subject: "Damaged package"
   Query: "The package arrived damaged and the item is broken."
   Expected status: NEEDS_HUMAN / AI escalates to claims support.

8. Name: Riya Joshi
   Subject: "Change delivery address"
   Query: "Can I change the delivery address before it ships?"
   Expected status: OPEN / AI answers if shipment has not dispatched.

9. Name: Aditya Sharma
   Subject: "Product warranty"
   Query: "Is this product covered under warranty for 1 year?"
   Expected status: OPEN / AI provides warranty info.

10. Name: Tamanna Gupta
    Subject: "Refund status"
    Query: "I requested a refund last week. When will I get it?"
    Expected status: NEEDS_HUMAN / AI checks refund status and escalates.

---

## Key Points to Remember

| Entity  | What it Stores | Example |
|---------|---|---|
| **users** | Customer name | "Priya Sharma" |
| **tickets** | Support request details | Order complaint, delivery status, etc. |
| **messages** | Chat messages in conversation | "Where is my order?" |

| Field | Possible Values |
|---|---|
| **status** | OPEN, NEEDS_HUMAN, RESOLVED |
| **sender** | USER, AI, ADMIN |

---

## Testing the System

### Test Case 1: Normal AI Response
```
Input:  "Where is my order?"
Status: OPEN (AI will respond)
```

### Test Case 2: Escalation
```
Input:  "I want a REFUND!"
Status: NEEDS_HUMAN (AI flags for human)
```

### Test Case 3: Multiple Keywords
```
Input:  "This product is terrible, I'm furious, need a refund!"
Keywords detected: "terrible", "furious", "refund"
Status: NEEDS_HUMAN (escalated)
```

---

## Where to Test

1. **Chat Page**: `http://localhost:5173/` → Fill form, send message
2. **H2 Console**: `http://localhost:8081/h2-console` → View raw tables
3. **Admin Dashboard**: `http://localhost:5173/` → Switch to "Admin Dashboard" tab
